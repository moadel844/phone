import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { Card, Chip, Button, Divider } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/theme';

const CaseDetailsScreen = ({ route, navigation }: any) => {
  const { case: caseData } = route.params;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'جديد': return colors.info;
      case 'قيد المراجعة': return colors.warning;
      case 'في المحكمة': return '#8B5CF6';
      case 'مغلق': return colors.success;
      default: return colors.gray[400];
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'عالي': return colors.error;
      case 'متوسط': return colors.warning;
      case 'منخفض': return colors.success;
      default: return colors.gray[400];
    }
  };

  const handleEditCase = () => {
    Alert.alert('تعديل القضية', 'سيتم فتح شاشة تعديل القضية');
  };

  const handleAddDocument = () => {
    Alert.alert('إضافة مستند', 'سيتم فتح منتقي الملفات');
  };

  const handleScheduleHearing = () => {
    Alert.alert('جدولة جلسة', 'سيتم فتح التقويم لجدولة جلسة جديدة');
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Case Header */}
      <Card style={styles.headerCard}>
        <Card.Content style={styles.headerContent}>
          <View style={styles.headerTop}>
            <View style={styles.caseNumberContainer}>
              <Text style={styles.caseNumber}>{caseData.caseNumber}</Text>
              <Chip
                mode="outlined"
                style={[styles.statusChip, { borderColor: getStatusColor(caseData.status) }]}
                textStyle={[styles.statusText, { color: getStatusColor(caseData.status) }]}
              >
                {caseData.status}
              </Chip>
            </View>
            <View style={styles.priorityBadge}>
              <Ionicons
                name="flag"
                size={16}
                color={getPriorityColor(caseData.priority)}
              />
              <Text style={[styles.priorityText, { color: getPriorityColor(caseData.priority) }]}>
                {caseData.priority}
              </Text>
            </View>
          </View>

          <Text style={styles.caseTitle}>{caseData.title}</Text>

          <View style={styles.caseMetadata}>
            <View style={styles.metadataRow}>
              <Ionicons name="person" size={18} color={colors.gray[500]} />
              <Text style={styles.metadataLabel}>العميل:</Text>
              <Text style={styles.metadataValue}>{caseData.client}</Text>
            </View>
            <View style={styles.metadataRow}>
              <Ionicons name="briefcase" size={18} color={colors.gray[500]} />
              <Text style={styles.metadataLabel}>نوع القضية:</Text>
              <Text style={styles.metadataValue}>{caseData.caseType}</Text>
            </View>
            <View style={styles.metadataRow}>
              <Ionicons name="person-circle" size={18} color={colors.gray[500]} />
              <Text style={styles.metadataLabel}>المحامي المسؤول:</Text>
              <Text style={styles.metadataValue}>{caseData.assignedLawyer}</Text>
            </View>
          </View>
        </Card.Content>
      </Card>

      {/* Next Hearing */}
      {caseData.nextHearing && (
        <Card style={styles.hearingCard}>
          <Card.Content style={styles.hearingContent}>
            <View style={styles.hearingHeader}>
              <Ionicons name="calendar" size={24} color={colors.warning} />
              <Text style={styles.hearingTitle}>الجلسة القادمة</Text>
            </View>
            <Text style={styles.hearingDate}>
              {new Date(caseData.nextHearing).toLocaleDateString('ar-EG', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric',
              })}
            </Text>
            <Text style={styles.hearingTime}>الساعة 10:00 صباحاً</Text>
            <Text style={styles.hearingLocation}>محكمة شمال القاهرة الابتدائية</Text>
          </Card.Content>
        </Card>
      )}

      {/* Case Description */}
      <Card style={styles.descriptionCard}>
        <Card.Content>
          <Text style={styles.sectionTitle}>وصف القضية</Text>
          <Text style={styles.descriptionText}>
            نزاع حول ملكية قطعة أرض في شارع النيل، المنطقة السكنية الجديدة. 
            تتضمن القضية مراجعة العقود والوثائق القانونية المتعلقة بالملكية 
            والتحقق من صحة المستندات المقدمة من الأطراف المختلفة.
          </Text>
        </Card.Content>
      </Card>

      {/* Documents */}
      <Card style={styles.documentsCard}>
        <Card.Content>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>المستندات</Text>
            <TouchableOpacity onPress={handleAddDocument} style={styles.addButton}>
              <Ionicons name="add-circle" size={20} color={colors.primary} />
            </TouchableOpacity>
          </View>

          <View style={styles.documentsList}>
            <TouchableOpacity style={styles.documentItem}>
              <View style={styles.documentIcon}>
                <Ionicons name="document-text" size={24} color={colors.error} />
              </View>
              <View style={styles.documentInfo}>
                <Text style={styles.documentName}>عقد الملكية الأصلي.pdf</Text>
                <Text style={styles.documentDetails}>2.3 MB • تم الرفع في 15 يناير 2024</Text>
              </View>
              <TouchableOpacity style={styles.documentAction}>
                <Ionicons name="download" size={20} color={colors.gray[500]} />
              </TouchableOpacity>
            </TouchableOpacity>

            <TouchableOpacity style={styles.documentItem}>
              <View style={styles.documentIcon}>
                <Ionicons name="document-text" size={24} color={colors.info} />
              </View>
              <View style={styles.documentInfo}>
                <Text style={styles.documentName}>مرافعة الدفاع.docx</Text>
                <Text style={styles.documentDetails}>1.8 MB • تم الرفع في 18 يناير 2024</Text>
              </View>
              <TouchableOpacity style={styles.documentAction}>
                <Ionicons name="download" size={20} color={colors.gray[500]} />
              </TouchableOpacity>
            </TouchableOpacity>
          </View>
        </Card.Content>
      </Card>

      {/* Timeline */}
      <Card style={styles.timelineCard}>
        <Card.Content>
          <Text style={styles.sectionTitle}>سجل الأحداث</Text>
          
          <View style={styles.timeline}>
            <View style={styles.timelineItem}>
              <View style={[styles.timelineIcon, { backgroundColor: colors.success }]}>
                <Ionicons name="checkmark" size={16} color={colors.white} />
              </View>
              <View style={styles.timelineContent}>
                <Text style={styles.timelineTitle}>تم إنشاء القضية</Text>
                <Text style={styles.timelineDate}>15 يناير 2024</Text>
              </View>
            </View>

            <View style={styles.timelineItem}>
              <View style={[styles.timelineIcon, { backgroundColor: colors.info }]}>
                <Ionicons name="document-attach" size={16} color={colors.white} />
              </View>
              <View style={styles.timelineContent}>
                <Text style={styles.timelineTitle}>تم رفع المستندات الأولية</Text>
                <Text style={styles.timelineDate}>16 يناير 2024</Text>
              </View>
            </View>

            <View style={styles.timelineItem}>
              <View style={[styles.timelineIcon, { backgroundColor: colors.warning }]}>
                <Ionicons name="calendar" size={16} color={colors.white} />
              </View>
              <View style={styles.timelineContent}>
                <Text style={styles.timelineTitle}>تم جدولة الجلسة الأولى</Text>
                <Text style={styles.timelineDate}>20 يناير 2024</Text>
              </View>
            </View>
          </View>
        </Card.Content>
      </Card>

      {/* Action Buttons */}
      <View style={styles.actionsContainer}>
        <Button
          mode="contained"
          onPress={handleEditCase}
          style={[styles.actionButton, { backgroundColor: colors.primary }]}
          labelStyle={styles.actionButtonText}
          icon="pencil"
        >
          تعديل القضية
        </Button>

        <Button
          mode="outlined"
          onPress={handleScheduleHearing}
          style={[styles.actionButton, styles.outlinedButton]}
          labelStyle={[styles.actionButtonText, { color: colors.primary }]}
          icon="calendar-plus"
        >
          جدولة جلسة
        </Button>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.gray[50],
  },
  headerCard: {
    margin: 20,
    marginBottom: 15,
    borderRadius: 12,
    elevation: 3,
  },
  headerContent: {
    padding: 20,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 15,
  },
  caseNumberContainer: {
    flex: 1,
  },
  caseNumber: {
    fontSize: 14,
    color: colors.gray[500],
    fontFamily: 'monospace',
    marginBottom: 8,
  },
  statusChip: {
    alignSelf: 'flex-start',
    height: 32,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  priorityBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.gray[100],
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  priorityText: {
    fontSize: 12,
    fontWeight: '600',
    marginLeft: 4,
  },
  caseTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.gray[800],
    marginBottom: 20,
    lineHeight: 28,
  },
  caseMetadata: {
    marginTop: 10,
  },
  metadataRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  metadataLabel: {
    fontSize: 14,
    color: colors.gray[600],
    marginLeft: 8,
    minWidth: 80,
  },
  metadataValue: {
    fontSize: 14,
    color: colors.gray[800],
    fontWeight: '500',
    flex: 1,
  },
  hearingCard: {
    marginHorizontal: 20,
    marginBottom: 15,
    borderRadius: 12,
    elevation: 2,
    backgroundColor: '#FEF3C7',
  },
  hearingContent: {
    padding: 20,
  },
  hearingHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  hearingTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#92400E',
    marginLeft: 8,
  },
  hearingDate: {
    fontSize: 16,
    fontWeight: '600',
    color: '#92400E',
    marginBottom: 4,
  },
  hearingTime: {
    fontSize: 14,
    color: '#92400E',
    marginBottom: 4,
  },
  hearingLocation: {
    fontSize: 14,
    color: '#92400E',
  },
  descriptionCard: {
    marginHorizontal: 20,
    marginBottom: 15,
    borderRadius: 12,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.gray[800],
    marginBottom: 12,
  },
  descriptionText: {
    fontSize: 14,
    color: colors.gray[700],
    lineHeight: 22,
  },
  documentsCard: {
    marginHorizontal: 20,
    marginBottom: 15,
    borderRadius: 12,
    elevation: 2,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  addButton: {
    padding: 4,
  },
  documentsList: {
    marginTop: 10,
  },
  documentItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.gray[100],
  },
  documentIcon: {
    marginRight: 12,
  },
  documentInfo: {
    flex: 1,
  },
  documentName: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.gray[800],
    marginBottom: 4,
  },
  documentDetails: {
    fontSize: 12,
    color: colors.gray[500],
  },
  documentAction: {
    padding: 8,
  },
  timelineCard: {
    marginHorizontal: 20,
    marginBottom: 15,
    borderRadius: 12,
    elevation: 2,
  },
  timeline: {
    marginTop: 10,
  },
  timelineItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 20,
  },
  timelineIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  timelineContent: {
    flex: 1,
    paddingTop: 4,
  },
  timelineTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.gray[800],
    marginBottom: 4,
  },
  timelineDate: {
    fontSize: 12,
    color: colors.gray[500],
  },
  actionsContainer: {
    paddingHorizontal: 20,
    paddingBottom: 30,
    marginTop: 10,
  },
  actionButton: {
    marginBottom: 12,
    borderRadius: 8,
    paddingVertical: 4,
  },
  outlinedButton: {
    borderColor: colors.primary,
    borderWidth: 1,
  },
  actionButtonText: {
    fontSize: 16,
    fontWeight: '600',
  },
});

export default CaseDetailsScreen;