import React, { useState } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
} from 'react-native';
import { Card, FAB, Chip, Searchbar } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/theme';

const CasesScreen = ({ navigation }: any) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('الكل');

  const cases = [
    {
      id: '1',
      caseNumber: 'LAW-2024-001',
      title: 'قضية نزاع عقاري - شارع النيل',
      client: 'أحمد محمد علي',
      caseType: 'عقاري',
      status: 'في المحكمة',
      priority: 'عالي',
      nextHearing: '2024-02-15',
      assignedLawyer: 'المستشار محمد أحمد',
    },
    {
      id: '2',
      caseNumber: 'LAW-2024-002',
      title: 'قضية تجارية - نزاع شراكة',
      client: 'شركة النور للتجارة',
      caseType: 'تجاري',
      status: 'قيد المراجعة',
      priority: 'متوسط',
      assignedLawyer: 'المستشارة سارة أحمد',
    },
    {
      id: '3',
      caseNumber: 'LAW-2024-003',
      title: 'قضية عمالية - فصل تعسفي',
      client: 'محمد عبدالله',
      caseType: 'عمالي',
      status: 'جديد',
      priority: 'عالي',
      assignedLawyer: 'المستشار خالد عبدالله',
    },
  ];

  const filters = ['الكل', 'جديد', 'قيد المراجعة', 'في المحكمة', 'مغلق'];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'جديد': return colors.info;
      case 'قيد المراجعة': return colors.warning;
      case 'في المحكمة': return '#8B5CF6';
      case 'مغلق': return colors.success;
      default: return colors.gray[400];
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'عالي': return 'alert-circle';
      case 'متوسط': return 'time';
      case 'منخفض': return 'checkmark-circle';
      default: return 'help-circle';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'عالي': return colors.error;
      case 'متوسط': return colors.warning;
      case 'منخفض': return colors.success;
      default: return colors.gray[400];
    }
  };

  const filteredCases = cases.filter(caseItem => {
    const matchesSearch = caseItem.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         caseItem.client.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         caseItem.caseNumber.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesFilter = selectedFilter === 'الكل' || caseItem.status === selectedFilter;
    
    return matchesSearch && matchesFilter;
  });

  const renderCaseCard = ({ item }: any) => (
    <TouchableOpacity
      onPress={() => navigation.navigate('CaseDetails', { case: item })}
      style={styles.caseCard}
    >
      <Card style={styles.card}>
        <Card.Content style={styles.cardContent}>
          <View style={styles.cardHeader}>
            <View style={styles.caseInfo}>
              <Text style={styles.caseNumber}>{item.caseNumber}</Text>
              <Chip
                mode="outlined"
                style={[styles.statusChip, { borderColor: getStatusColor(item.status) }]}
                textStyle={[styles.statusText, { color: getStatusColor(item.status) }]}
              >
                {item.status}
              </Chip>
            </View>
            <View style={styles.priorityContainer}>
              <Ionicons
                name={getPriorityIcon(item.priority)}
                size={20}
                color={getPriorityColor(item.priority)}
              />
            </View>
          </View>

          <Text style={styles.caseTitle} numberOfLines={2}>
            {item.title}
          </Text>

          <View style={styles.caseDetails}>
            <View style={styles.detailRow}>
              <Ionicons name="person" size={16} color={colors.gray[500]} />
              <Text style={styles.detailText}>{item.client}</Text>
            </View>
            <View style={styles.detailRow}>
              <Ionicons name="briefcase" size={16} color={colors.gray[500]} />
              <Text style={styles.detailText}>{item.caseType}</Text>
            </View>
            <View style={styles.detailRow}>
              <Ionicons name="person-circle" size={16} color={colors.gray[500]} />
              <Text style={styles.detailText} numberOfLines={1}>
                {item.assignedLawyer}
              </Text>
            </View>
          </View>

          {item.nextHearing && (
            <View style={styles.hearingContainer}>
              <Ionicons name="calendar" size={16} color={colors.warning} />
              <Text style={styles.hearingText}>
                الجلسة القادمة: {new Date(item.nextHearing).toLocaleDateString('ar-EG')}
              </Text>
            </View>
          )}
        </Card.Content>
      </Card>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>القضايا</Text>
        <Text style={styles.headerSubtitle}>إدارة جميع قضايا المكتب</Text>
      </View>

      {/* Search */}
      <View style={styles.searchContainer}>
        <Searchbar
          placeholder="البحث في القضايا..."
          onChangeText={setSearchQuery}
          value={searchQuery}
          style={styles.searchBar}
          inputStyle={styles.searchInput}
          iconColor={colors.gray[500]}
        />
      </View>

      {/* Filters */}
      <View style={styles.filtersContainer}>
        <FlatList
          horizontal
          showsHorizontalScrollIndicator={false}
          data={filters}
          keyExtractor={(item) => item}
          renderItem={({ item }) => (
            <TouchableOpacity
              onPress={() => setSelectedFilter(item)}
              style={[
                styles.filterChip,
                selectedFilter === item && styles.activeFilterChip,
              ]}
            >
              <Text
                style={[
                  styles.filterText,
                  selectedFilter === item && styles.activeFilterText,
                ]}
              >
                {item}
              </Text>
            </TouchableOpacity>
          )}
          contentContainerStyle={styles.filtersContent}
        />
      </View>

      {/* Cases List */}
      <FlatList
        data={filteredCases}
        keyExtractor={(item) => item.id}
        renderItem={renderCaseCard}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Ionicons name="folder-open-outline" size={64} color={colors.gray[300]} />
            <Text style={styles.emptyTitle}>لا توجد قضايا</Text>
            <Text style={styles.emptySubtitle}>
              {searchQuery || selectedFilter !== 'الكل'
                ? 'لم يتم العثور على قضايا تطابق معايير البحث'
                : 'ابدأ بإضافة قضية جديدة'
              }
            </Text>
          </View>
        }
      />

      {/* FAB */}
      <FAB
        icon="plus"
        style={styles.fab}
        onPress={() => navigation.navigate('AddCase')}
        color={colors.white}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.gray[50],
  },
  header: {
    backgroundColor: colors.primary,
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.white,
  },
  headerSubtitle: {
    fontSize: 16,
    color: colors.white,
    opacity: 0.9,
    marginTop: 5,
  },
  searchContainer: {
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  searchBar: {
    elevation: 2,
    borderRadius: 12,
  },
  searchInput: {
    textAlign: 'right',
  },
  filtersContainer: {
    paddingVertical: 10,
  },
  filtersContent: {
    paddingHorizontal: 20,
  },
  filterChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 10,
    borderRadius: 20,
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.gray[300],
  },
  activeFilterChip: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  filterText: {
    fontSize: 14,
    color: colors.gray[700],
    fontWeight: '500',
  },
  activeFilterText: {
    color: colors.white,
  },
  listContainer: {
    paddingHorizontal: 20,
    paddingBottom: 100,
  },
  caseCard: {
    marginBottom: 15,
  },
  card: {
    borderRadius: 12,
    elevation: 2,
  },
  cardContent: {
    padding: 16,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  caseInfo: {
    flex: 1,
  },
  caseNumber: {
    fontSize: 12,
    color: colors.gray[500],
    fontFamily: 'monospace',
    marginBottom: 6,
  },
  statusChip: {
    alignSelf: 'flex-start',
    height: 28,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  priorityContainer: {
    marginLeft: 10,
  },
  caseTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.gray[800],
    marginBottom: 12,
    lineHeight: 22,
  },
  caseDetails: {
    marginBottom: 12,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  detailText: {
    fontSize: 14,
    color: colors.gray[600],
    marginLeft: 8,
    flex: 1,
  },
  hearingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FEF3C7',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
  },
  hearingText: {
    fontSize: 12,
    color: '#92400E',
    fontWeight: '600',
    marginLeft: 6,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.gray[700],
    marginTop: 16,
  },
  emptySubtitle: {
    fontSize: 14,
    color: colors.gray[500],
    textAlign: 'center',
    marginTop: 8,
    paddingHorizontal: 40,
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
    backgroundColor: colors.primary,
  },
});

export default CasesScreen;