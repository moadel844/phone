import React, { useState } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import { Card, FAB, Chip, SegmentedButtons } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/theme';

const AppointmentsScreen = ({ navigation }: any) => {
  const [selectedPeriod, setSelectedPeriod] = useState('اليوم');

  const appointments = [
    {
      id: '1',
      title: 'جلسة محكمة - قضية النزاع العقاري',
      date: '2024-02-15',
      time: '10:00',
      type: 'جلسة محكمة',
      clientName: 'أحمد محمد علي',
      location: 'محكمة شمال القاهرة',
      status: 'مؤكد',
      reminder: true,
    },
    {
      id: '2',
      title: 'استشارة قانونية',
      date: '2024-02-15',
      time: '14:00',
      type: 'استشارة',
      clientName: 'شركة النور للتجارة',
      location: 'مكتب المحاماة',
      status: 'مجدول',
      reminder: true,
    },
    {
      id: '3',
      title: 'اجتماع مع العميل',
      date: '2024-02-16',
      time: '11:30',
      type: 'اجتماع عميل',
      clientName: 'فاطمة حسن محمود',
      location: 'مكتب المحاماة',
      status: 'مؤكد',
      reminder: false,
    },
  ];

  const periods = [
    { value: 'اليوم', label: 'اليوم' },
    { value: 'هذا الأسبوع', label: 'الأسبوع' },
    { value: 'هذا الشهر', label: 'الشهر' },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'مؤكد': return colors.success;
      case 'مجدول': return colors.info;
      case 'ملغي': return colors.error;
      case 'مكتمل': return colors.gray[500];
      default: return colors.gray[400];
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'جلسة محكمة': return 'gavel';
      case 'استشارة': return 'chatbubble-ellipses';
      case 'اجتماع عميل': return 'people';
      case 'مراجعة مستندات': return 'document-text';
      default: return 'calendar';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'جلسة محكمة': return '#8B5CF6';
      case 'استشارة': return colors.info;
      case 'اجتماع عميل': return colors.success;
      case 'مراجعة مستندات': return colors.warning;
      default: return colors.gray[500];
    }
  };

  const isToday = (date: string) => {
    const today = new Date().toISOString().split('T')[0];
    return date === today;
  };

  const isTomorrow = (date: string) => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return date === tomorrow.toISOString().split('T')[0];
  };

  const formatDate = (date: string) => {
    if (isToday(date)) return 'اليوم';
    if (isTomorrow(date)) return 'غداً';
    return new Date(date).toLocaleDateString('ar-EG', {
      weekday: 'long',
      month: 'short',
      day: 'numeric',
    });
  };

  const renderAppointmentCard = ({ item }: any) => (
    <TouchableOpacity style={styles.appointmentCard}>
      <Card style={styles.card}>
        <Card.Content style={styles.cardContent}>
          <View style={styles.appointmentHeader}>
            <View style={styles.appointmentInfo}>
              <View style={styles.typeContainer}>
                <View style={[styles.typeIcon, { backgroundColor: getTypeColor(item.type) }]}>
                  <Ionicons
                    name={getTypeIcon(item.type)}
                    size={16}
                    color={colors.white}
                  />
                </View>
                <Text style={styles.appointmentType}>{item.type}</Text>
              </View>
              <Chip
                mode="outlined"
                style={[styles.statusChip, { borderColor: getStatusColor(item.status) }]}
                textStyle={[styles.statusText, { color: getStatusColor(item.status) }]}
              >
                {item.status}
              </Chip>
            </View>
            {item.reminder && (
              <View style={styles.reminderIcon}>
                <Ionicons name="notifications" size={16} color={colors.warning} />
              </View>
            )}
          </View>

          <Text style={styles.appointmentTitle} numberOfLines={2}>
            {item.title}
          </Text>

          <View style={styles.appointmentDetails}>
            <View style={styles.detailRow}>
              <Ionicons name="person" size={16} color={colors.gray[500]} />
              <Text style={styles.detailText}>{item.clientName}</Text>
            </View>
            <View style={styles.detailRow}>
              <Ionicons name="location" size={16} color={colors.gray[500]} />
              <Text style={styles.detailText} numberOfLines={1}>
                {item.location}
              </Text>
            </View>
          </View>

          <View style={styles.timeContainer}>
            <View style={styles.timeInfo}>
              <Ionicons name="calendar" size={16} color={colors.primary} />
              <Text style={styles.dateText}>{formatDate(item.date)}</Text>
            </View>
            <View style={styles.timeInfo}>
              <Ionicons name="time" size={16} color={colors.primary} />
              <Text style={styles.timeText}>{item.time}</Text>
            </View>
          </View>
        </Card.Content>
      </Card>
    </TouchableOpacity>
  );

  const todayAppointments = appointments.filter(apt => isToday(apt.date));
  const upcomingAppointments = appointments.filter(apt => !isToday(apt.date));

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>المواعيد</Text>
        <Text style={styles.headerSubtitle}>تنظيم ومتابعة جميع المواعيد</Text>
      </View>

      {/* Period Filter */}
      <View style={styles.filterContainer}>
        <SegmentedButtons
          value={selectedPeriod}
          onValueChange={setSelectedPeriod}
          buttons={periods}
          style={styles.segmentedButtons}
        />
      </View>

      {/* Today's Appointments */}
      {todayAppointments.length > 0 && (
        <View style={styles.sectionContainer}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>مواعيد اليوم</Text>
            <View style={styles.sectionBadge}>
              <Text style={styles.sectionBadgeText}>{todayAppointments.length}</Text>
            </View>
          </View>
          <FlatList
            data={todayAppointments}
            keyExtractor={(item) => `today-${item.id}`}
            renderItem={renderAppointmentCard}
            showsVerticalScrollIndicator={false}
            scrollEnabled={false}
          />
        </View>
      )}

      {/* Upcoming Appointments */}
      <View style={styles.sectionContainer}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>المواعيد القادمة</Text>
          <View style={styles.sectionBadge}>
            <Text style={styles.sectionBadgeText}>{upcomingAppointments.length}</Text>
          </View>
        </View>
        <FlatList
          data={upcomingAppointments}
          keyExtractor={(item) => `upcoming-${item.id}`}
          renderItem={renderAppointmentCard}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Ionicons name="calendar-outline" size={64} color={colors.gray[300]} />
              <Text style={styles.emptyTitle}>لا توجد مواعيد قادمة</Text>
              <Text style={styles.emptySubtitle}>
                جميع المواعيد محدثة
              </Text>
            </View>
          }
        />
      </View>

      {/* FAB */}
      <FAB
        icon="plus"
        style={styles.fab}
        onPress={() => {}}
        color={colors.white}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.gray[50],
  },
  header: {
    backgroundColor: colors.primary,
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.white,
  },
  headerSubtitle: {
    fontSize: 16,
    color: colors.white,
    opacity: 0.9,
    marginTop: 5,
  },
  filterContainer: {
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  segmentedButtons: {
    backgroundColor: colors.white,
  },
  sectionContainer: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.gray[800],
  },
  sectionBadge: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    paddingHorizontal: 8,
    paddingVertical: 4,
    minWidth: 24,
    alignItems: 'center',
  },
  sectionBadgeText: {
    color: colors.white,
    fontSize: 12,
    fontWeight: 'bold',
  },
  listContainer: {
    paddingBottom: 100,
  },
  appointmentCard: {
    marginBottom: 12,
  },
  card: {
    borderRadius: 12,
    elevation: 2,
  },
  cardContent: {
    padding: 16,
  },
  appointmentHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  appointmentInfo: {
    flex: 1,
  },
  typeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  typeIcon: {
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 8,
  },
  appointmentType: {
    fontSize: 12,
    color: colors.gray[600],
    fontWeight: '500',
  },
  statusChip: {
    alignSelf: 'flex-start',
    height: 28,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  reminderIcon: {
    marginLeft: 10,
  },
  appointmentTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.gray[800],
    marginBottom: 12,
    lineHeight: 22,
  },
  appointmentDetails: {
    marginBottom: 12,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  detailText: {
    fontSize: 14,
    color: colors.gray[600],
    marginLeft: 8,
    flex: 1,
  },
  timeContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: colors.gray[50],
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
  },
  timeInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  dateText: {
    fontSize: 12,
    color: colors.primary,
    fontWeight: '600',
    marginLeft: 6,
  },
  timeText: {
    fontSize: 12,
    color: colors.primary,
    fontWeight: '600',
    marginLeft: 6,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 40,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.gray[700],
    marginTop: 16,
  },
  emptySubtitle: {
    fontSize: 14,
    color: colors.gray[500],
    textAlign: 'center',
    marginTop: 8,
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
    backgroundColor: colors.primary,
  },
});

export default AppointmentsScreen;