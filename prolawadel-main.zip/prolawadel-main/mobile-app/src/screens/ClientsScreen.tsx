import React, { useState } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import { Card, FAB, Searchbar, Avatar, Chip } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/theme';

const ClientsScreen = ({ navigation }: any) => {
  const [searchQuery, setSearchQuery] = useState('');

  const clients = [
    {
      id: '1',
      name: 'أحمد محمد علي',
      email: 'ahmed.ali@email.com',
      phone: '01012345678',
      type: 'فرد',
      activeCases: 2,
      totalPaid: 50000,
      rating: 5,
      lastContact: '2024-01-20',
    },
    {
      id: '2',
      name: 'شركة النور للتجارة',
      email: 'info@alnoor.com',
      phone: '01123456789',
      type: 'شركة',
      activeCases: 1,
      totalPaid: 200000,
      rating: 4,
      lastContact: '2024-01-18',
    },
    {
      id: '3',
      name: 'فاطمة حسن محمود',
      email: 'fatma.hassan@email.com',
      phone: '01098765432',
      type: 'فرد',
      activeCases: 1,
      totalPaid: 25000,
      rating: 5,
      lastContact: '2024-01-15',
    },
  ];

  const filteredClients = clients.filter(client =>
    client.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    client.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    client.phone.includes(searchQuery)
  );

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').substring(0, 2);
  };

  const getClientTypeColor = (type: string) => {
    return type === 'شركة' ? colors.info : colors.success;
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Ionicons
        key={index}
        name={index < rating ? 'star' : 'star-outline'}
        size={14}
        color={colors.warning}
      />
    ));
  };

  const renderClientCard = ({ item }: any) => (
    <TouchableOpacity style={styles.clientCard}>
      <Card style={styles.card}>
        <Card.Content style={styles.cardContent}>
          <View style={styles.clientHeader}>
            <Avatar.Text
              size={50}
              label={getInitials(item.name)}
              style={[styles.avatar, { backgroundColor: getClientTypeColor(item.type) }]}
              labelStyle={styles.avatarLabel}
            />
            <View style={styles.clientInfo}>
              <Text style={styles.clientName} numberOfLines={1}>
                {item.name}
              </Text>
              <View style={styles.clientMeta}>
                <Chip
                  mode="outlined"
                  style={[styles.typeChip, { borderColor: getClientTypeColor(item.type) }]}
                  textStyle={[styles.typeText, { color: getClientTypeColor(item.type) }]}
                >
                  {item.type}
                </Chip>
                <View style={styles.rating}>
                  {renderStars(item.rating)}
                </View>
              </View>
            </View>
          </View>

          <View style={styles.contactInfo}>
            <View style={styles.contactRow}>
              <Ionicons name="mail" size={16} color={colors.gray[500]} />
              <Text style={styles.contactText} numberOfLines={1}>
                {item.email}
              </Text>
            </View>
            <View style={styles.contactRow}>
              <Ionicons name="call" size={16} color={colors.gray[500]} />
              <Text style={styles.contactText}>{item.phone}</Text>
            </View>
          </View>

          <View style={styles.clientStats}>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{item.activeCases}</Text>
              <Text style={styles.statLabel}>قضايا نشطة</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={styles.statValue}>
                {(item.totalPaid / 1000).toFixed(0)}K
              </Text>
              <Text style={styles.statLabel}>إجمالي المدفوعات</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={styles.statValue}>
                {new Date(item.lastContact).toLocaleDateString('ar-EG', { 
                  month: 'short', 
                  day: 'numeric' 
                })}
              </Text>
              <Text style={styles.statLabel}>آخر تواصل</Text>
            </View>
          </View>

          <View style={styles.actionButtons}>
            <TouchableOpacity style={styles.actionButton}>
              <Ionicons name="call" size={18} color={colors.success} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionButton}>
              <Ionicons name="mail" size={18} color={colors.info} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionButton}>
              <Ionicons name="chatbubble" size={18} color={colors.primary} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionButton}>
              <Ionicons name="ellipsis-horizontal" size={18} color={colors.gray[500]} />
            </TouchableOpacity>
          </View>
        </Card.Content>
      </Card>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>العملاء</Text>
        <Text style={styles.headerSubtitle}>إدارة جميع عملاء المكتب</Text>
      </View>

      {/* Search */}
      <View style={styles.searchContainer}>
        <Searchbar
          placeholder="البحث في العملاء..."
          onChangeText={setSearchQuery}
          value={searchQuery}
          style={styles.searchBar}
          inputStyle={styles.searchInput}
          iconColor={colors.gray[500]}
        />
      </View>

      {/* Stats */}
      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{clients.length}</Text>
          <Text style={styles.statText}>إجمالي العملاء</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>
            {clients.filter(c => c.activeCases > 0).length}
          </Text>
          <Text style={styles.statText}>عملاء نشطين</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>
            {clients.filter(c => c.type === 'شركة').length}
          </Text>
          <Text style={styles.statText}>شركات</Text>
        </View>
      </View>

      {/* Clients List */}
      <FlatList
        data={filteredClients}
        keyExtractor={(item) => item.id}
        renderItem={renderClientCard}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Ionicons name="people-outline" size={64} color={colors.gray[300]} />
            <Text style={styles.emptyTitle}>لا توجد عملاء</Text>
            <Text style={styles.emptySubtitle}>
              {searchQuery
                ? 'لم يتم العثور على عملاء تطابق معايير البحث'
                : 'ابدأ بإضافة عميل جديد'
              }
            </Text>
          </View>
        }
      />

      {/* FAB */}
      <FAB
        icon="plus"
        style={styles.fab}
        onPress={() => {}}
        color={colors.white}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.gray[50],
  },
  header: {
    backgroundColor: colors.primary,
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.white,
  },
  headerSubtitle: {
    fontSize: 16,
    color: colors.white,
    opacity: 0.9,
    marginTop: 5,
  },
  searchContainer: {
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  searchBar: {
    elevation: 2,
    borderRadius: 12,
  },
  searchInput: {
    textAlign: 'right',
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 15,
  },
  statCard: {
    flex: 1,
    backgroundColor: colors.white,
    padding: 15,
    marginHorizontal: 5,
    borderRadius: 12,
    alignItems: 'center',
    elevation: 2,
  },
  statNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.primary,
  },
  statText: {
    fontSize: 12,
    color: colors.gray[600],
    marginTop: 4,
  },
  listContainer: {
    paddingHorizontal: 20,
    paddingBottom: 100,
  },
  clientCard: {
    marginBottom: 15,
  },
  card: {
    borderRadius: 12,
    elevation: 2,
  },
  cardContent: {
    padding: 16,
  },
  clientHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  avatar: {
    marginRight: 12,
  },
  avatarLabel: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  clientInfo: {
    flex: 1,
  },
  clientName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.gray[800],
    marginBottom: 6,
  },
  clientMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  typeChip: {
    height: 24,
    alignSelf: 'flex-start',
  },
  typeText: {
    fontSize: 10,
    fontWeight: '600',
  },
  rating: {
    flexDirection: 'row',
  },
  contactInfo: {
    marginBottom: 15,
  },
  contactRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  contactText: {
    fontSize: 14,
    color: colors.gray[600],
    marginLeft: 8,
    flex: 1,
  },
  clientStats: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    paddingVertical: 12,
    backgroundColor: colors.gray[50],
    borderRadius: 8,
    marginBottom: 15,
  },
  statItem: {
    alignItems: 'center',
    flex: 1,
  },
  statValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.gray[800],
  },
  statLabel: {
    fontSize: 10,
    color: colors.gray[500],
    marginTop: 2,
  },
  statDivider: {
    width: 1,
    height: 30,
    backgroundColor: colors.gray[200],
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  actionButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.gray[100],
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.gray[700],
    marginTop: 16,
  },
  emptySubtitle: {
    fontSize: 14,
    color: colors.gray[500],
    textAlign: 'center',
    marginTop: 8,
    paddingHorizontal: 40,
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
    backgroundColor: colors.primary,
  },
});

export default ClientsScreen;