import React, { useState } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import { Card, FAB, Chip, SegmentedButtons, ProgressBar } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/theme';

const TasksScreen = ({ navigation }: any) => {
  const [selectedFilter, setSelectedFilter] = useState('الكل');

  const tasks = [
    {
      id: '1',
      title: 'مراجعة عقد الملكية',
      description: 'مراجعة قانونية شاملة لعقد الملكية للقضية العقارية',
      assignedTo: 'المستشار محمد أحمد',
      caseTitle: 'قضية نزاع عقاري - شارع النيل',
      priority: 'عالي',
      status: 'قيد التنفيذ',
      dueDate: '2024-02-10',
      progress: 65,
      estimatedHours: 8,
      actualHours: 5,
    },
    {
      id: '2',
      title: 'إعداد مذكرة قانونية',
      description: 'إعداد مذكرة قانونية للقضية التجارية',
      assignedTo: 'المستشارة سارة أحمد',
      caseTitle: 'قضية تجارية - نزاع شراكة',
      priority: 'متوسط',
      status: 'جديد',
      dueDate: '2024-02-15',
      progress: 0,
      estimatedHours: 12,
      actualHours: 0,
    },
    {
      id: '3',
      title: 'تحضير ملف الدعوى',
      description: 'تجميع وتنظيم جميع المستندات المطلوبة للدعوى',
      assignedTo: 'المستشار خالد عبدالله',
      caseTitle: 'قضية عمالية - فصل تعسفي',
      priority: 'عالي',
      status: 'مكتمل',
      dueDate: '2024-02-05',
      progress: 100,
      estimatedHours: 6,
      actualHours: 7,
    },
  ];

  const filters = [
    { value: 'الكل', label: 'الكل' },
    { value: 'جديد', label: 'جديد' },
    { value: 'قيد التنفيذ', label: 'قيد التنفيذ' },
    { value: 'مكتمل', label: 'مكتمل' },
  ];

  const filteredTasks = tasks.filter(task => 
    selectedFilter === 'الكل' || task.status === selectedFilter
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'جديد': return colors.info;
      case 'قيد التنفيذ': return colors.warning;
      case 'مكتمل': return colors.success;
      case 'متأخر': return colors.error;
      case 'ملغي': return colors.gray[500];
      default: return colors.gray[400];
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'عالي': return colors.error;
      case 'متوسط': return colors.warning;
      case 'منخفض': return colors.success;
      default: return colors.gray[400];
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'عالي': return 'alert-circle';
      case 'متوسط': return 'time';
      case 'منخفض': return 'checkmark-circle';
      default: return 'help-circle';
    }
  };

  const isOverdue = (dueDate: string) => {
    return new Date(dueDate) < new Date() && new Date(dueDate).toDateString() !== new Date().toDateString();
  };

  const getDaysUntilDue = (dueDate: string) => {
    const today = new Date();
    const due = new Date(dueDate);
    const diffTime = due.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const formatDueDate = (dueDate: string) => {
    const days = getDaysUntilDue(dueDate);
    if (days === 0) return 'اليوم';
    if (days === 1) return 'غداً';
    if (days === -1) return 'أمس';
    if (days < 0) return `متأخر ${Math.abs(days)} يوم`;
    return `خلال ${days} يوم`;
  };

  const renderTaskCard = ({ item }: any) => (
    <TouchableOpacity style={styles.taskCard}>
      <Card style={styles.card}>
        <Card.Content style={styles.cardContent}>
          <View style={styles.taskHeader}>
            <View style={styles.taskInfo}>
              <View style={styles.priorityContainer}>
                <Ionicons
                  name={getPriorityIcon(item.priority)}
                  size={16}
                  color={getPriorityColor(item.priority)}
                />
                <Text style={[styles.priorityText, { color: getPriorityColor(item.priority) }]}>
                  {item.priority}
                </Text>
              </View>
              <Chip
                mode="outlined"
                style={[styles.statusChip, { borderColor: getStatusColor(item.status) }]}
                textStyle={[styles.statusText, { color: getStatusColor(item.status) }]}
              >
                {item.status}
              </Chip>
            </View>
          </View>

          <Text style={styles.taskTitle} numberOfLines={2}>
            {item.title}
          </Text>

          <Text style={styles.taskDescription} numberOfLines={2}>
            {item.description}
          </Text>

          <View style={styles.caseInfo}>
            <Ionicons name="folder" size={14} color={colors.gray[500]} />
            <Text style={styles.caseTitle} numberOfLines={1}>
              {item.caseTitle}
            </Text>
          </View>

          <View style={styles.assigneeInfo}>
            <Ionicons name="person" size={14} color={colors.gray[500]} />
            <Text style={styles.assigneeText}>{item.assignedTo}</Text>
          </View>

          {/* Progress Bar */}
          <View style={styles.progressContainer}>
            <View style={styles.progressHeader}>
              <Text style={styles.progressLabel}>التقدم</Text>
              <Text style={styles.progressPercentage}>{item.progress}%</Text>
            </View>
            <ProgressBar
              progress={item.progress / 100}
              color={getStatusColor(item.status)}
              style={styles.progressBar}
            />
          </View>

          {/* Time Info */}
          <View style={styles.timeInfo}>
            <View style={styles.timeItem}>
              <Ionicons name="time" size={14} color={colors.gray[500]} />
              <Text style={styles.timeText}>
                {item.actualHours || 0}/{item.estimatedHours}ساعة
              </Text>
            </View>
            <View style={[
              styles.dueDateContainer,
              isOverdue(item.dueDate) && styles.overdueContainer
            ]}>
              <Ionicons 
                name="calendar" 
                size={14} 
                color={isOverdue(item.dueDate) ? colors.error : colors.gray[500]} 
              />
              <Text style={[
                styles.dueDateText,
                isOverdue(item.dueDate) && styles.overdueText
              ]}>
                {formatDueDate(item.dueDate)}
              </Text>
            </View>
          </View>
        </Card.Content>
      </Card>
    </TouchableOpacity>
  );

  const taskStats = {
    total: tasks.length,
    new: tasks.filter(t => t.status === 'جديد').length,
    inProgress: tasks.filter(t => t.status === 'قيد التنفيذ').length,
    completed: tasks.filter(t => t.status === 'مكتمل').length,
    overdue: tasks.filter(t => isOverdue(t.dueDate) && t.status !== 'مكتمل').length,
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>المهام</Text>
        <Text style={styles.headerSubtitle}>تنظيم ومتابعة جميع المهام</Text>
      </View>

      {/* Stats */}
      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{taskStats.total}</Text>
          <Text style={styles.statLabel}>إجمالي</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={[styles.statNumber, { color: colors.info }]}>{taskStats.new}</Text>
          <Text style={styles.statLabel}>جديد</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={[styles.statNumber, { color: colors.warning }]}>{taskStats.inProgress}</Text>
          <Text style={styles.statLabel}>قيد التنفيذ</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={[styles.statNumber, { color: colors.success }]}>{taskStats.completed}</Text>
          <Text style={styles.statLabel}>مكتمل</Text>
        </View>
      </View>

      {/* Filter */}
      <View style={styles.filterContainer}>
        <SegmentedButtons
          value={selectedFilter}
          onValueChange={setSelectedFilter}
          buttons={filters}
          style={styles.segmentedButtons}
        />
      </View>

      {/* Tasks List */}
      <FlatList
        data={filteredTasks}
        keyExtractor={(item) => item.id}
        renderItem={renderTaskCard}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Ionicons name="checkmark-done-outline" size={64} color={colors.gray[300]} />
            <Text style={styles.emptyTitle}>لا توجد مهام</Text>
            <Text style={styles.emptySubtitle}>
              {selectedFilter !== 'الكل'
                ? `لا توجد مهام ${selectedFilter}`
                : 'ابدأ بإضافة مهمة جديدة'
              }
            </Text>
          </View>
        }
      />

      {/* FAB */}
      <FAB
        icon="plus"
        style={styles.fab}
        onPress={() => {}}
        color={colors.white}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.gray[50],
  },
  header: {
    backgroundColor: colors.primary,
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.white,
  },
  headerSubtitle: {
    fontSize: 16,
    color: colors.white,
    opacity: 0.9,
    marginTop: 5,
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  statCard: {
    flex: 1,
    backgroundColor: colors.white,
    padding: 12,
    marginHorizontal: 3,
    borderRadius: 8,
    alignItems: 'center',
    elevation: 1,
  },
  statNumber: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.gray[800],
  },
  statLabel: {
    fontSize: 10,
    color: colors.gray[600],
    marginTop: 2,
  },
  filterContainer: {
    paddingHorizontal: 20,
    paddingBottom: 15,
  },
  segmentedButtons: {
    backgroundColor: colors.white,
  },
  listContainer: {
    paddingHorizontal: 20,
    paddingBottom: 100,
  },
  taskCard: {
    marginBottom: 12,
  },
  card: {
    borderRadius: 12,
    elevation: 2,
  },
  cardContent: {
    padding: 16,
  },
  taskHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  taskInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
  },
  priorityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  priorityText: {
    fontSize: 12,
    fontWeight: '600',
    marginLeft: 4,
  },
  statusChip: {
    height: 28,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  taskTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.gray[800],
    marginBottom: 8,
    lineHeight: 22,
  },
  taskDescription: {
    fontSize: 14,
    color: colors.gray[600],
    marginBottom: 12,
    lineHeight: 20,
  },
  caseInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  caseTitle: {
    fontSize: 12,
    color: colors.gray[500],
    marginLeft: 6,
    flex: 1,
  },
  assigneeInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  assigneeText: {
    fontSize: 12,
    color: colors.gray[500],
    marginLeft: 6,
  },
  progressContainer: {
    marginBottom: 12,
  },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  progressLabel: {
    fontSize: 12,
    color: colors.gray[600],
    fontWeight: '500',
  },
  progressPercentage: {
    fontSize: 12,
    color: colors.gray[800],
    fontWeight: 'bold',
  },
  progressBar: {
    height: 6,
    borderRadius: 3,
    backgroundColor: colors.gray[200],
  },
  timeInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  timeItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  timeText: {
    fontSize: 12,
    color: colors.gray[500],
    marginLeft: 4,
  },
  dueDateContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.gray[100],
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  overdueContainer: {
    backgroundColor: '#FEE2E2',
  },
  dueDateText: {
    fontSize: 12,
    color: colors.gray[600],
    marginLeft: 4,
    fontWeight: '500',
  },
  overdueText: {
    color: colors.error,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.gray[700],
    marginTop: 16,
  },
  emptySubtitle: {
    fontSize: 14,
    color: colors.gray[500],
    textAlign: 'center',
    marginTop: 8,
    paddingHorizontal: 40,
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
    backgroundColor: colors.primary,
  },
});

export default TasksScreen;