import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { Card, Avatar, Divider, Switch } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '../theme/theme';

const ProfileScreen = ({ navigation }: any) => {
  const [notificationsEnabled, setNotificationsEnabled] = React.useState(true);
  const [darkModeEnabled, setDarkModeEnabled] = React.useState(false);

  const userProfile = {
    name: 'المستشار محمد أحمد',
    email: 'mohamed.ahmed@almostashar.com',
    phone: '+20 12 3456 7890',
    position: 'محامي أول',
    experience: '15 سنة',
    specialization: 'القانون المدني والتجاري',
    cases: 156,
    successRate: 87,
    clientSatisfaction: 94,
  };

  const menuItems = [
    {
      id: 'personal',
      title: 'المعلومات الشخصية',
      icon: 'person',
      onPress: () => Alert.alert('المعلومات الشخصية', 'سيتم فتح شاشة تعديل المعلومات الشخصية'),
    },
    {
      id: 'security',
      title: 'الأمان والخصوصية',
      icon: 'shield-checkmark',
      onPress: () => Alert.alert('الأمان والخصوصية', 'سيتم فتح إعدادات الأمان'),
    },
    {
      id: 'notifications',
      title: 'إعدادات الإشعارات',
      icon: 'notifications',
      onPress: () => Alert.alert('الإشعارات', 'سيتم فتح إعدادات الإشعارات'),
    },
    {
      id: 'language',
      title: 'اللغة والمنطقة',
      icon: 'language',
      onPress: () => Alert.alert('اللغة', 'سيتم فتح إعدادات اللغة'),
    },
    {
      id: 'backup',
      title: 'النسخ الاحتياطي',
      icon: 'cloud-upload',
      onPress: () => Alert.alert('النسخ الاحتياطي', 'سيتم فتح إعدادات النسخ الاحتياطي'),
    },
    {
      id: 'help',
      title: 'المساعدة والدعم',
      icon: 'help-circle',
      onPress: () => Alert.alert('المساعدة', 'سيتم فتح مركز المساعدة'),
    },
    {
      id: 'about',
      title: 'حول التطبيق',
      icon: 'information-circle',
      onPress: () => Alert.alert('حول التطبيق', 'المستشار v1.0.0\nنظام إدارة مكتب المحاماة'),
    },
  ];

  const handleLogout = () => {
    Alert.alert(
      'تسجيل الخروج',
      'هل أنت متأكد من تسجيل الخروج؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        { text: 'تسجيل الخروج', style: 'destructive', onPress: () => {} },
      ]
    );
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Profile Header */}
      <LinearGradient
        colors={[colors.primary, '#F97316']}
        style={styles.header}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      >
        <View style={styles.profileSection}>
          <Avatar.Text
            size={80}
            label="م.أ"
            style={styles.avatar}
            labelStyle={styles.avatarLabel}
          />
          <Text style={styles.userName}>{userProfile.name}</Text>
          <Text style={styles.userPosition}>{userProfile.position}</Text>
          <Text style={styles.userEmail}>{userProfile.email}</Text>
        </View>
      </LinearGradient>

      {/* Stats Cards */}
      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{userProfile.cases}</Text>
          <Text style={styles.statLabel}>قضية</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{userProfile.successRate}%</Text>
          <Text style={styles.statLabel}>معدل النجاح</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{userProfile.clientSatisfaction}%</Text>
          <Text style={styles.statLabel}>رضا العملاء</Text>
        </View>
      </View>

      {/* Professional Info */}
      <Card style={styles.infoCard}>
        <Card.Content style={styles.infoContent}>
          <Text style={styles.sectionTitle}>المعلومات المهنية</Text>
          
          <View style={styles.infoRow}>
            <Ionicons name="briefcase" size={20} color={colors.gray[500]} />
            <View style={styles.infoText}>
              <Text style={styles.infoLabel}>التخصص</Text>
              <Text style={styles.infoValue}>{userProfile.specialization}</Text>
            </View>
          </View>

          <View style={styles.infoRow}>
            <Ionicons name="time" size={20} color={colors.gray[500]} />
            <View style={styles.infoText}>
              <Text style={styles.infoLabel}>سنوات الخبرة</Text>
              <Text style={styles.infoValue}>{userProfile.experience}</Text>
            </View>
          </View>

          <View style={styles.infoRow}>
            <Ionicons name="call" size={20} color={colors.gray[500]} />
            <View style={styles.infoText}>
              <Text style={styles.infoLabel}>رقم الهاتف</Text>
              <Text style={styles.infoValue}>{userProfile.phone}</Text>
            </View>
          </View>
        </Card.Content>
      </Card>

      {/* Quick Settings */}
      <Card style={styles.settingsCard}>
        <Card.Content style={styles.settingsContent}>
          <Text style={styles.sectionTitle}>الإعدادات السريعة</Text>
          
          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Ionicons name="notifications" size={20} color={colors.gray[500]} />
              <Text style={styles.settingLabel}>الإشعارات</Text>
            </View>
            <Switch
              value={notificationsEnabled}
              onValueChange={setNotificationsEnabled}
              color={colors.primary}
            />
          </View>

          <Divider style={styles.divider} />

          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Ionicons name="moon" size={20} color={colors.gray[500]} />
              <Text style={styles.settingLabel}>الوضع الليلي</Text>
            </View>
            <Switch
              value={darkModeEnabled}
              onValueChange={setDarkModeEnabled}
              color={colors.primary}
            />
          </View>
        </Card.Content>
      </Card>

      {/* Menu Items */}
      <Card style={styles.menuCard}>
        <Card.Content style={styles.menuContent}>
          <Text style={styles.sectionTitle}>الإعدادات</Text>
          
          {menuItems.map((item, index) => (
            <View key={item.id}>
              <TouchableOpacity style={styles.menuItem} onPress={item.onPress}>
                <View style={styles.menuItemLeft}>
                  <Ionicons name={item.icon as any} size={20} color={colors.gray[500]} />
                  <Text style={styles.menuItemText}>{item.title}</Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color={colors.gray[400]} />
              </TouchableOpacity>
              {index < menuItems.length - 1 && <Divider style={styles.divider} />}
            </View>
          ))}
        </Card.Content>
      </Card>

      {/* Logout Button */}
      <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
        <Ionicons name="log-out" size={20} color={colors.error} />
        <Text style={styles.logoutText}>تسجيل الخروج</Text>
      </TouchableOpacity>

      <View style={styles.footer}>
        <Text style={styles.footerText}>المستشار v1.0.0</Text>
        <Text style={styles.footerSubtext}>نظام إدارة مكتب المحاماة</Text>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.gray[50],
  },
  header: {
    paddingTop: 50,
    paddingBottom: 40,
    paddingHorizontal: 20,
  },
  profileSection: {
    alignItems: 'center',
  },
  avatar: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    marginBottom: 15,
  },
  avatarLabel: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.white,
  },
  userName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.white,
    marginBottom: 5,
  },
  userPosition: {
    fontSize: 16,
    color: colors.white,
    opacity: 0.9,
    marginBottom: 5,
  },
  userEmail: {
    fontSize: 14,
    color: colors.white,
    opacity: 0.8,
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginTop: -20,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    backgroundColor: colors.white,
    padding: 20,
    marginHorizontal: 5,
    borderRadius: 12,
    alignItems: 'center',
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  statNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.primary,
  },
  statLabel: {
    fontSize: 12,
    color: colors.gray[600],
    marginTop: 4,
  },
  infoCard: {
    marginHorizontal: 20,
    marginBottom: 15,
    borderRadius: 12,
    elevation: 2,
  },
  infoContent: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.gray[800],
    marginBottom: 20,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  infoText: {
    marginLeft: 15,
    flex: 1,
  },
  infoLabel: {
    fontSize: 12,
    color: colors.gray[500],
    marginBottom: 2,
  },
  infoValue: {
    fontSize: 14,
    color: colors.gray[800],
    fontWeight: '500',
  },
  settingsCard: {
    marginHorizontal: 20,
    marginBottom: 15,
    borderRadius: 12,
    elevation: 2,
  },
  settingsContent: {
    padding: 20,
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    pad: 15,
  },
  settingInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingLabel: {
    fontSize: 16,
    color: colors.gray[800],
    marginLeft: 15,
  },
  divider: {
    marginVertical: 15,
  },
  menuCard: {
    marginHorizontal: 20,
    marginBottom: 20,
    borderRadius: 12,
    elevation: 2,
  },
  menuContent: {
    padding: 20,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 15,
  },
  menuItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  menuItemText: {
    fontSize: 16,
    color: colors.gray[800],
    marginLeft: 15,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.white,
    marginHorizontal: 20,
    paddingVertical: 15,
    borderRadius: 12,
    elevation: 2,
    marginBottom: 20,
  },
  logoutText: {
    fontSize: 16,
    color: colors.error,
    fontWeight: '600',
    marginLeft: 10,
  },
  footer: {
    alignItems: 'center',
    paddingVertical: 20,
    paddingBottom: 40,
  },
  footerText: {
    fontSize: 14,
    color: colors.gray[600],
    fontWeight: '600',
  },
  footerSubtext: {
    fontSize: 12,
    color: colors.gray[500],
    marginTop: 2,
  },
});

export default ProfileScreen;