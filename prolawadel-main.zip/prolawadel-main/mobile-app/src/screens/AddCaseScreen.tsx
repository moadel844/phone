import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import {
  TextInput,
  Button,
  Card,
  SegmentedButtons,
  HelperText,
} from 'react-native-paper';
import { Picker } from '@react-native-picker/picker';
import { colors } from '../theme/theme';

const AddCaseScreen = ({ navigation }: any) => {
  const [formData, setFormData] = useState({
    title: '',
    client: '',
    caseType: 'مدني',
    priority: 'متوسط',
    description: '',
    assignedLawyer: '',
    nextHearing: '',
  });

  const [errors, setErrors] = useState<any>({});

  const caseTypes = [
    { label: 'مدني', value: 'مدني' },
    { label: 'جنائي', value: 'جنائي' },
    { label: 'تجاري', value: 'تجاري' },
    { label: 'عمالي', value: 'عمالي' },
    { label: 'أحوال شخصية', value: 'أحوال شخصية' },
    { label: 'إداري', value: 'إداري' },
    { label: 'عقاري', value: 'عقاري' },
  ];

  const priorities = [
    { value: 'منخفض', label: 'منخفض' },
    { value: 'متوسط', label: 'متوسط' },
    { value: 'عالي', label: 'عالي' },
  ];

  const lawyers = [
    'المستشار محمد أحمد',
    'المستشارة سارة أحمد',
    'المستشار خالد عبدالله',
    'المستشار أحمد فتحي',
  ];

  const validateForm = () => {
    const newErrors: any = {};

    if (!formData.title.trim()) {
      newErrors.title = 'عنوان القضية مطلوب';
    }

    if (!formData.client.trim()) {
      newErrors.client = 'اسم العميل مطلوب';
    }

    if (!formData.description.trim()) {
      newErrors.description = 'وصف القضية مطلوب';
    }

    if (!formData.assignedLawyer) {
      newErrors.assignedLawyer = 'يجب اختيار المحامي المسؤول';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (validateForm()) {
      const newCase = {
        ...formData,
        id: Date.now().toString(),
        caseNumber: `LAW-2024-${String(Date.now()).slice(-3)}`,
        status: 'جديد',
        createdDate: new Date().toISOString().split('T')[0],
        lastUpdated: new Date().toISOString().split('T')[0],
      };

      Alert.alert(
        'تم إنشاء القضية',
        'تم إنشاء القضية الجديدة بنجاح',
        [
          {
            text: 'موافق',
            onPress: () => navigation.goBack(),
          },
        ]
      );
    }
  };

  const updateFormData = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev: any) => ({ ...prev, [field]: null }));
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <Card style={styles.formCard}>
          <Card.Content style={styles.formContent}>
            <Text style={styles.formTitle}>إضافة قضية جديدة</Text>
            <Text style={styles.formSubtitle}>
              املأ البيانات التالية لإنشاء قضية جديدة
            </Text>

            {/* Case Title */}
            <View style={styles.inputContainer}>
              <TextInput
                label="عنوان القضية *"
                value={formData.title}
                onChangeText={(text) => updateFormData('title', text)}
                mode="outlined"
                style={styles.textInput}
                error={!!errors.title}
                placeholder="أدخل عنوان القضية"
              />
              <HelperText type="error" visible={!!errors.title}>
                {errors.title}
              </HelperText>
            </View>

            {/* Client Name */}
            <View style={styles.inputContainer}>
              <TextInput
                label="اسم العميل *"
                value={formData.client}
                onChangeText={(text) => updateFormData('client', text)}
                mode="outlined"
                style={styles.textInput}
                error={!!errors.client}
                placeholder="اسم العميل"
              />
              <HelperText type="error" visible={!!errors.client}>
                {errors.client}
              </HelperText>
            </View>

            {/* Case Type */}
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>نوع القضية</Text>
              <View style={styles.pickerContainer}>
                <Picker
                  selectedValue={formData.caseType}
                  onValueChange={(value) => updateFormData('caseType', value)}
                  style={styles.picker}
                >
                  {caseTypes.map((type) => (
                    <Picker.Item
                      key={type.value}
                      label={type.label}
                      value={type.value}
                    />
                  ))}
                </Picker>
              </View>
            </View>

            {/* Priority */}
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>الأولوية</Text>
              <SegmentedButtons
                value={formData.priority}
                onValueChange={(value) => updateFormData('priority', value)}
                buttons={priorities}
                style={styles.segmentedButtons}
              />
            </View>

            {/* Assigned Lawyer */}
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>المحامي المسؤول *</Text>
              <View style={styles.pickerContainer}>
                <Picker
                  selectedValue={formData.assignedLawyer}
                  onValueChange={(value) => updateFormData('assignedLawyer', value)}
                  style={styles.picker}
                >
                  <Picker.Item label="اختر المحامي" value="" />
                  {lawyers.map((lawyer) => (
                    <Picker.Item
                      key={lawyer}
                      label={lawyer}
                      value={lawyer}
                    />
                  ))}
                </Picker>
              </View>
              <HelperText type="error" visible={!!errors.assignedLawyer}>
                {errors.assignedLawyer}
              </HelperText>
            </View>

            {/* Next Hearing Date */}
            <View style={styles.inputContainer}>
              <TextInput
                label="تاريخ الجلسة القادمة"
                value={formData.nextHearing}
                onChangeText={(text) => updateFormData('nextHearing', text)}
                mode="outlined"
                style={styles.textInput}
                placeholder="YYYY-MM-DD"
                keyboardType="numeric"
              />
              <HelperText type="info">
                اختياري - يمكن إضافته لاحقاً
              </HelperText>
            </View>

            {/* Description */}
            <View style={styles.inputContainer}>
              <TextInput
                label="وصف القضية *"
                value={formData.description}
                onChangeText={(text) => updateFormData('description', text)}
                mode="outlined"
                style={styles.textArea}
                multiline
                numberOfLines={4}
                error={!!errors.description}
                placeholder="وصف تفصيلي للقضية"
              />
              <HelperText type="error" visible={!!errors.description}>
                {errors.description}
              </HelperText>
            </View>
          </Card.Content>
        </Card>

        {/* Action Buttons */}
        <View style={styles.actionsContainer}>
          <Button
            mode="contained"
            onPress={handleSubmit}
            style={styles.submitButton}
            labelStyle={styles.submitButtonText}
            icon="content-save"
          >
            حفظ القضية
          </Button>

          <Button
            mode="outlined"
            onPress={() => navigation.goBack()}
            style={styles.cancelButton}
            labelStyle={styles.cancelButtonText}
          >
            إلغاء
          </Button>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.gray[50],
  },
  scrollView: {
    flex: 1,
  },
  formCard: {
    margin: 20,
    borderRadius: 12,
    elevation: 2,
  },
  formContent: {
    padding: 20,
  },
  formTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.gray[800],
    marginBottom: 8,
    textAlign: 'center',
  },
  formSubtitle: {
    fontSize: 14,
    color: colors.gray[600],
    textAlign: 'center',
    marginBottom: 30,
  },
  inputContainer: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.gray[700],
    marginBottom: 8,
  },
  textInput: {
    backgroundColor: colors.white,
  },
  textArea: {
    backgroundColor: colors.white,
    minHeight: 100,
  },
  pickerContainer: {
    borderWidth: 1,
    borderColor: colors.gray[300],
    borderRadius: 8,
    backgroundColor: colors.white,
  },
  picker: {
    height: 50,
  },
  segmentedButtons: {
    marginTop: 8,
  },
  actionsContainer: {
    paddingHorizontal: 20,
    paddingBottom: 30,
  },
  submitButton: {
    backgroundColor: colors.primary,
    marginBottom: 12,
    borderRadius: 8,
    paddingVertical: 4,
  },
  submitButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.white,
  },
  cancelButton: {
    borderColor: colors.gray[400],
    borderRadius: 8,
    paddingVertical: 4,
  },
  cancelButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.gray[600],
  },
});

export default AddCaseScreen;