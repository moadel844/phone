import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
} from 'react-native';
import { Card, Title, Paragraph } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { BarChart, PieChart } from 'react-native-chart-kit';
import { colors } from '../theme/theme';

const { width } = Dimensions.get('window');

const DashboardScreen = ({ navigation }: any) => {
  const statistics = {
    totalCases: 25,
    activeCases: 18,
    closedCases: 7,
    upcomingHearings: 5,
    totalClients: 42,
    todayTasks: 8,
  };

  const chartData = {
    labels: ['مدني', 'جنائي', 'تجاري', 'عمالي'],
    datasets: [
      {
        data: [8, 5, 7, 5],
      },
    ],
  };

  const pieData = [
    {
      name: 'نشطة',
      population: 18,
      color: colors.success,
      legendFontColor: colors.gray[700],
      legendFontSize: 12,
    },
    {
      name: 'مغلقة',
      population: 7,
      color: colors.gray[400],
      legendFontColor: colors.gray[700],
      legendFontSize: 12,
    },
  ];

  const StatCard = ({ title, value, icon, color, onPress }: any) => (
    <TouchableOpacity onPress={onPress} style={styles.statCard}>
      <LinearGradient
        colors={[color, `${color}CC`]}
        style={styles.statGradient}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      >
        <View style={styles.statContent}>
          <View style={styles.statIcon}>
            <Ionicons name={icon} size={24} color={colors.white} />
          </View>
          <View style={styles.statText}>
            <Text style={styles.statValue}>{value}</Text>
            <Text style={styles.statTitle}>{title}</Text>
          </View>
        </View>
      </LinearGradient>
    </TouchableOpacity>
  );

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <LinearGradient
        colors={[colors.primary, '#F97316']}
        style={styles.header}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      >
        <View style={styles.headerContent}>
          <View>
            <Text style={styles.welcomeText}>مرحباً بك</Text>
            <Text style={styles.headerTitle}>المستشار</Text>
            <Text style={styles.headerSubtitle}>نظام إدارة مكتب المحاماة</Text>
          </View>
          <TouchableOpacity style={styles.profileButton}>
            <Ionicons name="person-circle" size={40} color={colors.white} />
          </TouchableOpacity>
        </View>
      </LinearGradient>

      {/* Statistics Cards */}
      <View style={styles.statsContainer}>
        <View style={styles.statsRow}>
          <StatCard
            title="إجمالي القضايا"
            value={statistics.totalCases}
            icon="document-text"
            color={colors.info}
            onPress={() => navigation.navigate('Cases')}
          />
          <StatCard
            title="القضايا النشطة"
            value={statistics.activeCases}
            icon="trending-up"
            color={colors.success}
            onPress={() => navigation.navigate('Cases')}
          />
        </View>
        <View style={styles.statsRow}>
          <StatCard
            title="الجلسات القادمة"
            value={statistics.upcomingHearings}
            icon="calendar"
            color={colors.warning}
            onPress={() => navigation.navigate('Appointments')}
          />
          <StatCard
            title="إجمالي العملاء"
            value={statistics.totalClients}
            icon="people"
            color={colors.secondary}
            onPress={() => navigation.navigate('Clients')}
          />
        </View>
      </View>

      {/* Quick Actions */}
      <Card style={styles.quickActionsCard}>
        <Card.Content>
          <Title style={styles.sectionTitle}>إجراءات سريعة</Title>
          <View style={styles.quickActions}>
            <TouchableOpacity
              style={styles.quickAction}
              onPress={() => navigation.navigate('Cases', { screen: 'AddCase' })}
            >
              <View style={[styles.quickActionIcon, { backgroundColor: colors.primary }]}>
                <Ionicons name="add-circle" size={24} color={colors.white} />
              </View>
              <Text style={styles.quickActionText}>قضية جديدة</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.quickAction}
              onPress={() => navigation.navigate('Clients')}
            >
              <View style={[styles.quickActionIcon, { backgroundColor: colors.info }]}>
                <Ionicons name="person-add" size={24} color={colors.white} />
              </View>
              <Text style={styles.quickActionText}>عميل جديد</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.quickAction}
              onPress={() => navigation.navigate('Appointments')}
            >
              <View style={[styles.quickActionIcon, { backgroundColor: colors.success }]}>
                <Ionicons name="calendar-outline" size={24} color={colors.white} />
              </View>
              <Text style={styles.quickActionText}>موعد جديد</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.quickAction}
              onPress={() => navigation.navigate('Tasks')}
            >
              <View style={[styles.quickActionIcon, { backgroundColor: colors.secondary }]}>
                <Ionicons name="checkbox" size={24} color={colors.white} />
              </View>
              <Text style={styles.quickActionText}>مهمة جديدة</Text>
            </TouchableOpacity>
          </View>
        </Card.Content>
      </Card>

      {/* Charts */}
      <Card style={styles.chartCard}>
        <Card.Content>
          <Title style={styles.sectionTitle}>توزيع القضايا حسب النوع</Title>
          <BarChart
            data={chartData}
            width={width - 60}
            height={200}
            yAxisLabel=""
            yAxisSuffix=""
            chartConfig={{
              backgroundColor: colors.white,
              backgroundGradientFrom: colors.white,
              backgroundGradientTo: colors.white,
              decimalPlaces: 0,
              color: (opacity = 1) => `rgba(245, 158, 11, ${opacity})`,
              labelColor: (opacity = 1) => `rgba(75, 85, 99, ${opacity})`,
              style: {
                borderRadius: 16,
              },
              propsForDots: {
                r: '6',
                strokeWidth: '2',
                stroke: colors.primary,
              },
            }}
            style={styles.chart}
          />
        </Card.Content>
      </Card>

      <Card style={styles.chartCard}>
        <Card.Content>
          <Title style={styles.sectionTitle}>حالة القضايا</Title>
          <PieChart
            data={pieData}
            width={width - 60}
            height={200}
            chartConfig={{
              color: (opacity = 1) => `rgba(245, 158, 11, ${opacity})`,
            }}
            accessor="population"
            backgroundColor="transparent"
            paddingLeft="15"
            absolute
          />
        </Card.Content>
      </Card>

      {/* Recent Activity */}
      <Card style={styles.activityCard}>
        <Card.Content>
          <Title style={styles.sectionTitle}>النشاط الأخير</Title>
          <View style={styles.activityList}>
            <View style={styles.activityItem}>
              <View style={[styles.activityIcon, { backgroundColor: colors.success }]}>
                <Ionicons name="checkmark" size={16} color={colors.white} />
              </View>
              <View style={styles.activityContent}>
                <Text style={styles.activityTitle}>تم إغلاق قضية النزاع التجاري</Text>
                <Text style={styles.activityTime}>منذ ساعتين</Text>
              </View>
            </View>

            <View style={styles.activityItem}>
              <View style={[styles.activityIcon, { backgroundColor: colors.info }]}>
                <Ionicons name="calendar" size={16} color={colors.white} />
              </View>
              <View style={styles.activityContent}>
                <Text style={styles.activityTitle}>جلسة محكمة غداً الساعة 10:00</Text>
                <Text style={styles.activityTime}>منذ 4 ساعات</Text>
              </View>
            </View>

            <View style={styles.activityItem}>
              <View style={[styles.activityIcon, { backgroundColor: colors.warning }]}>
                <Ionicons name="person-add" size={16} color={colors.white} />
              </View>
              <View style={styles.activityContent}>
                <Text style={styles.activityTitle}>تم إضافة عميل جديد</Text>
                <Text style={styles.activityTime}>أمس</Text>
              </View>
            </View>
          </View>
        </Card.Content>
      </Card>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.gray[50],
  },
  header: {
    paddingTop: 50,
    paddingBottom: 30,
    paddingHorizontal: 20,
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  welcomeText: {
    color: colors.white,
    fontSize: 16,
    opacity: 0.9,
  },
  headerTitle: {
    color: colors.white,
    fontSize: 28,
    fontWeight: 'bold',
    marginTop: 5,
  },
  headerSubtitle: {
    color: colors.white,
    fontSize: 14,
    opacity: 0.8,
    marginTop: 2,
  },
  profileButton: {
    padding: 5,
  },
  statsContainer: {
    paddingHorizontal: 20,
    marginTop: -20,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  statCard: {
    flex: 1,
    marginHorizontal: 5,
    borderRadius: 12,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  statGradient: {
    borderRadius: 12,
    padding: 15,
  },
  statContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statIcon: {
    marginRight: 12,
  },
  statText: {
    flex: 1,
  },
  statValue: {
    color: colors.white,
    fontSize: 24,
    fontWeight: 'bold',
  },
  statTitle: {
    color: colors.white,
    fontSize: 12,
    opacity: 0.9,
    marginTop: 2,
  },
  quickActionsCard: {
    margin: 20,
    borderRadius: 12,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.gray[800],
    marginBottom: 15,
  },
  quickActions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  quickAction: {
    alignItems: 'center',
    width: '22%',
    marginBottom: 15,
  },
  quickActionIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  quickActionText: {
    fontSize: 12,
    textAlign: 'center',
    color: colors.gray[700],
    fontWeight: '500',
  },
  chartCard: {
    margin: 20,
    marginTop: 0,
    borderRadius: 12,
    elevation: 2,
  },
  chart: {
    marginVertical: 8,
    borderRadius: 16,
  },
  activityCard: {
    margin: 20,
    marginTop: 0,
    marginBottom: 30,
    borderRadius: 12,
    elevation: 2,
  },
  activityList: {
    marginTop: 10,
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.gray[100],
  },
  activityIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  activityContent: {
    flex: 1,
  },
  activityTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.gray[800],
  },
  activityTime: {
    fontSize: 12,
    color: colors.gray[500],
    marginTop: 2,
  },
});

export default DashboardScreen;