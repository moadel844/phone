import React, { useState } from 'react';
import { Calendar, Clock, MapPin, User, Plus, Edit, Trash2, Bell, BellOff } from 'lucide-react';
import { Appointment, AppointmentType, AppointmentStatus } from '../types';

interface AppointmentCalendarProps {
  appointments: Appointment[];
  onAddAppointment: (appointment: Appointment) => void;
  onUpdateAppointment: (appointment: Appointment) => void;
  onDeleteAppointment: (id: string) => void;
}

export const AppointmentCalendar: React.FC<AppointmentCalendarProps> = ({
  appointments,
  onAddAppointment,
  onUpdateAppointment,
  onDeleteAppointment
}) => {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingAppointment, setEditingAppointment] = useState<Appointment | null>(null);

  const getAppointmentsForDate = (date: string) => {
    return appointments.filter(apt => apt.date === date);
  };

  const getStatusColor = (status: AppointmentStatus) => {
    switch (status) {
      case 'مجدول': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'مؤكد': return 'bg-green-100 text-green-800 border-green-200';
      case 'ملغي': return 'bg-red-100 text-red-800 border-red-200';
      case 'مكتمل': return 'bg-gray-100 text-gray-800 border-gray-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getTypeIcon = (type: AppointmentType) => {
    switch (type) {
      case 'جلسة محكمة': return '⚖️';
      case 'استشارة': return '💼';
      case 'اجتماع عميل': return '👥';
      case 'مراجعة مستندات': return '📄';
      default: return '📅';
    }
  };

  const todayAppointments = getAppointmentsForDate(selectedDate);
  const upcomingAppointments = appointments
    .filter(apt => apt.date > new Date().toISOString().split('T')[0])
    .sort((a, b) => new Date(a.date + ' ' + a.time).getTime() - new Date(b.date + ' ' + b.time).getTime())
    .slice(0, 5);

  return (
    <div className="space-y-6">
      {/* رأس القسم */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">إدارة المواعيد</h2>
          <p className="text-gray-600 mt-1">تنظيم ومتابعة جميع المواعيد والجلسات</p>
        </div>
        <button
          onClick={() => setIsAddModalOpen(true)}
          className="bg-amber-500 hover:bg-amber-600 text-white px-6 py-3 rounded-lg font-medium transition-colors flex items-center space-x-2 rtl:space-x-reverse"
        >
          <Plus className="h-4 w-4" />
          <span>موعد جديد</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* التقويم */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">التقويم</h3>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          {/* مواعيد اليوم المحدد */}
          <div className="space-y-4">
            <h4 className="font-medium text-gray-900">
              مواعيد يوم {new Date(selectedDate).toLocaleDateString('ar-EG')}
            </h4>
            
            {todayAppointments.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Calendar className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                <p>لا توجد مواعيد في هذا اليوم</p>
              </div>
            ) : (
              <div className="space-y-3">
                {todayAppointments.map((appointment) => (
                  <div key={appointment.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 rtl:space-x-reverse mb-2">
                          <span className="text-2xl">{getTypeIcon(appointment.type)}</span>
                          <div>
                            <h5 className="font-medium text-gray-900">{appointment.title}</h5>
                            <p className="text-sm text-gray-600">{appointment.clientName}</p>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm text-gray-600">
                          <div className="flex items-center space-x-2 rtl:space-x-reverse">
                            <Clock className="h-4 w-4" />
                            <span>{appointment.time}</span>
                          </div>
                          <div className="flex items-center space-x-2 rtl:space-x-reverse">
                            <MapPin className="h-4 w-4" />
                            <span>{appointment.location}</span>
                          </div>
                          <div className="flex items-center space-x-2 rtl:space-x-reverse">
                            {appointment.reminder ? (
                              <Bell className="h-4 w-4 text-amber-500" />
                            ) : (
                              <BellOff className="h-4 w-4" />
                            )}
                            <span>{appointment.reminder ? 'مفعل' : 'معطل'}</span>
                          </div>
                        </div>

                        <div className="flex items-center justify-between mt-3">
                          <span className={`text-xs px-2 py-1 rounded-full border ${getStatusColor(appointment.status)}`}>
                            {appointment.status}
                          </span>
                          
                          <div className="flex items-center space-x-2 rtl:space-x-reverse">
                            <button
                              onClick={() => setEditingAppointment(appointment)}
                              className="p-1 text-gray-500 hover:text-amber-600 hover:bg-amber-50 rounded"
                            >
                              <Edit className="h-4 w-4" />
                            </button>
                            <button
                              onClick={() => onDeleteAppointment(appointment.id)}
                              className="p-1 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* المواعيد القادمة */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">المواعيد القادمة</h3>
          
          {upcomingAppointments.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Calendar className="h-8 w-8 mx-auto mb-2 text-gray-300" />
              <p className="text-sm">لا توجد مواعيد قادمة</p>
            </div>
          ) : (
            <div className="space-y-3">
              {upcomingAppointments.map((appointment) => (
                <div key={appointment.id} className="border border-gray-200 rounded-lg p-3 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center space-x-3 rtl:space-x-reverse">
                    <span className="text-lg">{getTypeIcon(appointment.type)}</span>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-900 text-sm truncate">{appointment.title}</p>
                      <p className="text-xs text-gray-600">{appointment.clientName}</p>
                      <div className="flex items-center space-x-2 rtl:space-x-reverse text-xs text-gray-500 mt-1">
                        <span>{new Date(appointment.date).toLocaleDateString('ar-EG')}</span>
                        <span>•</span>
                        <span>{appointment.time}</span>
                      </div>
                    </div>
                    {appointment.reminder && (
                      <Bell className="h-4 w-4 text-amber-500" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* إحصائيات سريعة */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <Calendar className="h-5 w-5 text-blue-600" />
            <span className="text-sm font-medium text-blue-900">مواعيد اليوم</span>
          </div>
          <p className="text-2xl font-bold text-blue-600 mt-2">
            {getAppointmentsForDate(new Date().toISOString().split('T')[0]).length}
          </p>
        </div>

        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <Clock className="h-5 w-5 text-green-600" />
            <span className="text-sm font-medium text-green-900">هذا الأسبوع</span>
          </div>
          <p className="text-2xl font-bold text-green-600 mt-2">
            {appointments.filter(apt => {
              const aptDate = new Date(apt.date);
              const today = new Date();
              const weekFromNow = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);
              return aptDate >= today && aptDate <= weekFromNow;
            }).length}
          </p>
        </div>

        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <Bell className="h-5 w-5 text-amber-600" />
            <span className="text-sm font-medium text-amber-900">تذكيرات مفعلة</span>
          </div>
          <p className="text-2xl font-bold text-amber-600 mt-2">
            {appointments.filter(apt => apt.reminder).length}
          </p>
        </div>

        <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <User className="h-5 w-5 text-purple-600" />
            <span className="text-sm font-medium text-purple-900">جلسات محكمة</span>
          </div>
          <p className="text-2xl font-bold text-purple-600 mt-2">
            {appointments.filter(apt => apt.type === 'جلسة محكمة').length}
          </p>
        </div>
      </div>
    </div>
  );
};