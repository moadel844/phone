import React, { useState } from 'react';
import { 
  DollarSign, 
  TrendingUp, 
  TrendingDown, 
  CreditCard, 
  FileText, 
  Calendar,
  Plus,
  Download,
  Eye,
  Edit,
  Trash2
} from 'lucide-react';
import { Invoice, Payment } from '../types';

interface FinancialManagementProps {
  invoices: Invoice[];
  payments: Payment[];
  onAddInvoice: (invoice: Invoice) => void;
  onUpdateInvoice: (invoice: Invoice) => void;
  onDeleteInvoice: (id: string) => void;
  onAddPayment: (payment: Payment) => void;
}

export const FinancialManagement: React.FC<FinancialManagementProps> = ({
  invoices,
  payments,
  onAddInvoice,
  onUpdateInvoice,
  onDeleteInvoice,
  onAddPayment
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'invoices' | 'payments' | 'reports'>('overview');
  const [selectedPeriod, setSelectedPeriod] = useState('هذا الشهر');

  const totalRevenue = invoices.reduce((sum, inv) => sum + inv.total, 0);
  const paidAmount = invoices.filter(inv => inv.status === 'مدفوع').reduce((sum, inv) => sum + inv.total, 0);
  const pendingAmount = invoices.filter(inv => inv.status === 'مرسل').reduce((sum, inv) => sum + inv.total, 0);
  const overdueAmount = invoices.filter(inv => inv.status === 'متأخر').reduce((sum, inv) => sum + inv.total, 0);

  const FinancialCard = ({ 
    title, 
    amount, 
    icon: Icon, 
    color, 
    trend 
  }: { 
    title: string; 
    amount: number; 
    icon: any; 
    color: string;
    trend?: { value: number; isPositive: boolean };
  }) => (
    <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-gray-600 text-sm font-medium">{title}</p>
          <p className="text-3xl font-bold text-gray-900 mt-2">
            {amount.toLocaleString('ar-EG')} ج.م
          </p>
          {trend && (
            <div className={`flex items-center mt-2 text-sm ${trend.isPositive ? 'text-green-600' : 'text-red-600'}`}>
              {trend.isPositive ? (
                <TrendingUp className="h-4 w-4 ml-1" />
              ) : (
                <TrendingDown className="h-4 w-4 ml-1" />
              )}
              <span>{trend.value}% من الشهر الماضي</span>
            </div>
          )}
        </div>
        <div className={`p-4 rounded-xl ${color}`}>
          <Icon className="h-8 w-8 text-white" />
        </div>
      </div>
    </div>
  );

  const InvoiceTable = () => (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900">الفواتير</h3>
          <button className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2 rtl:space-x-reverse">
            <Plus className="h-4 w-4" />
            <span>فاتورة جديدة</span>
          </button>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="text-right py-3 px-6 font-medium text-gray-900">رقم الفاتورة</th>
              <th className="text-right py-3 px-6 font-medium text-gray-900">العميل</th>
              <th className="text-right py-3 px-6 font-medium text-gray-900">المبلغ</th>
              <th className="text-right py-3 px-6 font-medium text-gray-900">الحالة</th>
              <th className="text-right py-3 px-6 font-medium text-gray-900">تاريخ الإصدار</th>
              <th className="text-right py-3 px-6 font-medium text-gray-900">تاريخ الاستحقاق</th>
              <th className="text-right py-3 px-6 font-medium text-gray-900">إجراءات</th>
            </tr>
          </thead>
          <tbody>
            {invoices.map((invoice) => (
              <tr key={invoice.id} className="border-b border-gray-100 hover:bg-gray-50">
                <td className="py-4 px-6 font-mono text-sm">{invoice.invoiceNumber}</td>
                <td className="py-4 px-6">عميل {invoice.clientId}</td>
                <td className="py-4 px-6 font-medium">{invoice.total.toLocaleString('ar-EG')} ج.م</td>
                <td className="py-4 px-6">
                  <span className={`px-2 py-1 text-xs rounded-full ${
                    invoice.status === 'مدفوع' ? 'bg-green-100 text-green-800' :
                    invoice.status === 'مرسل' ? 'bg-blue-100 text-blue-800' :
                    invoice.status === 'متأخر' ? 'bg-red-100 text-red-800' :
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {invoice.status}
                  </span>
                </td>
                <td className="py-4 px-6 text-sm">{new Date(invoice.issueDate).toLocaleDateString('ar-EG')}</td>
                <td className="py-4 px-6 text-sm">{new Date(invoice.dueDate).toLocaleDateString('ar-EG')}</td>
                <td className="py-4 px-6">
                  <div className="flex items-center space-x-2 rtl:space-x-reverse">
                    <button className="p-1 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded">
                      <Eye className="h-4 w-4" />
                    </button>
                    <button className="p-1 text-gray-500 hover:text-green-600 hover:bg-green-50 rounded">
                      <Download className="h-4 w-4" />
                    </button>
                    <button className="p-1 text-gray-500 hover:text-amber-600 hover:bg-amber-50 rounded">
                      <Edit className="h-4 w-4" />
                    </button>
                    <button className="p-1 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const PaymentTable = () => (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900">المدفوعات</h3>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="text-right py-3 px-6 font-medium text-gray-900">رقم الفاتورة</th>
              <th className="text-right py-3 px-6 font-medium text-gray-900">المبلغ</th>
              <th className="text-right py-3 px-6 font-medium text-gray-900">طريقة الدفع</th>
              <th className="text-right py-3 px-6 font-medium text-gray-900">تاريخ الدفع</th>
              <th className="text-right py-3 px-6 font-medium text-gray-900">المرجع</th>
            </tr>
          </thead>
          <tbody>
            {payments.map((payment) => (
              <tr key={payment.id} className="border-b border-gray-100 hover:bg-gray-50">
                <td className="py-4 px-6 font-mono text-sm">{payment.invoiceId}</td>
                <td className="py-4 px-6 font-medium text-green-600">
                  {payment.amount.toLocaleString('ar-EG')} ج.م
                </td>
                <td className="py-4 px-6">{payment.paymentMethod}</td>
                <td className="py-4 px-6 text-sm">
                  {new Date(payment.paymentDate).toLocaleDateString('ar-EG')}
                </td>
                <td className="py-4 px-6 text-sm font-mono">{payment.reference}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <FinancialCard
                title="إجمالي الإيرادات"
                amount={totalRevenue}
                icon={DollarSign}
                color="bg-green-500"
                trend={{ value: 12, isPositive: true }}
              />
              <FinancialCard
                title="المبالغ المحصلة"
                amount={paidAmount}
                icon={TrendingUp}
                color="bg-blue-500"
                trend={{ value: 8, isPositive: true }}
              />
              <FinancialCard
                title="المبالغ المعلقة"
                amount={pendingAmount}
                icon={Calendar}
                color="bg-yellow-500"
                trend={{ value: 5, isPositive: false }}
              />
              <FinancialCard
                title="المبالغ المتأخرة"
                amount={overdueAmount}
                icon={TrendingDown}
                color="bg-red-500"
                trend={{ value: 15, isPositive: false }}
              />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">توزيع الإيرادات</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-700">أتعاب قانونية</span>
                    <div className="flex items-center space-x-2 rtl:space-x-reverse">
                      <div className="w-32 bg-gray-200 rounded-full h-3">
                        <div className="bg-green-500 h-3 rounded-full" style={{ width: '70%' }}></div>
                      </div>
                      <span className="text-sm font-medium text-gray-900">70%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-700">استشارات</span>
                    <div className="flex items-center space-x-2 rtl:space-x-reverse">
                      <div className="w-32 bg-gray-200 rounded-full h-3">
                        <div className="bg-blue-500 h-3 rounded-full" style={{ width: '20%' }}></div>
                      </div>
                      <span className="text-sm font-medium text-gray-900">20%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-700">خدمات أخرى</span>
                    <div className="flex items-center space-x-2 rtl:space-x-reverse">
                      <div className="w-32 bg-gray-200 rounded-full h-3">
                        <div className="bg-purple-500 h-3 rounded-full" style={{ width: '10%' }}></div>
                      </div>
                      <span className="text-sm font-medium text-gray-900">10%</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">الأداء الشهري</h3>
                <div className="space-y-4">
                  {[
                    { month: 'يناير', revenue: 150000, expenses: 80000 },
                    { month: 'فبراير', revenue: 180000, expenses: 90000 },
                    { month: 'مارس', revenue: 200000, expenses: 95000 },
                    { month: 'أبريل', revenue: 175000, expenses: 85000 }
                  ].map((data, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <span className="font-medium text-gray-900">{data.month}</span>
                      <div className="flex items-center space-x-4 rtl:space-x-reverse text-sm">
                        <div className="flex items-center space-x-2 rtl:space-x-reverse">
                          <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                          <span className="text-gray-600">إيرادات: {data.revenue.toLocaleString('ar-EG')}</span>
                        </div>
                        <div className="flex items-center space-x-2 rtl:space-x-reverse">
                          <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                          <span className="text-gray-600">مصروفات: {data.expenses.toLocaleString('ar-EG')}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        );
      case 'invoices':
        return <InvoiceTable />;
      case 'payments':
        return <PaymentTable />;
      case 'reports':
        return (
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">التقارير المالية</h3>
            <p className="text-gray-600">قريباً - تقارير مالية مفصلة</p>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">الإدارة المالية</h2>
          <p className="text-gray-600 mt-1">إدارة شاملة للفواتير والمدفوعات والتقارير المالية</p>
        </div>
        
        <div className="flex items-center space-x-4 rtl:space-x-reverse">
          <select
            value={selectedPeriod}
            onChange={(e) => setSelectedPeriod(e.target.value)}
            className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="هذا الشهر">هذا الشهر</option>
            <option value="الشهر الماضي">الشهر الماضي</option>
            <option value="هذا الربع">هذا الربع</option>
            <option value="هذا العام">هذا العام</option>
          </select>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-lg">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 rtl:space-x-reverse px-6">
            {[
              { id: 'overview', name: 'نظرة عامة', icon: DollarSign },
              { id: 'invoices', name: 'الفواتير', icon: FileText },
              { id: 'payments', name: 'المدفوعات', icon: CreditCard },
              { id: 'reports', name: 'التقارير', icon: TrendingUp }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 rtl:space-x-reverse py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{tab.name}</span>
                </button>
              );
            })}
          </nav>
        </div>
        
        <div className="p-6">
          {renderContent()}
        </div>
      </div>
    </div>
  );
};