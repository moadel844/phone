import React, { useState } from 'react';
import { X, Save } from 'lucide-react';
import { CaseType, CaseStatus, Priority } from '../types/core';

interface CompactAddCaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (caseData: any) => void;
}

export const CompactAddCaseModal: React.FC<CompactAddCaseModalProps> = ({ isOpen, onClose, onSave }) => {
  const [formData, setFormData] = useState({
    title: '',
    client: '',
    caseType: 'مدني' as CaseType,
    status: 'جديد' as CaseStatus,
    priority: 'متوسط' as Priority,
    description: '',
    assignedLawyer: '',
    nextHearing: ''
  });

  const caseTypes: CaseType[] = ['مدني', 'جنائي', 'تجاري', 'عمالي', 'أحوال شخصية', 'إداري', 'عقاري'];
  const statuses: CaseStatus[] = ['جديد', 'قيد المراجعة', 'في المحكمة', 'مؤجل', 'مغلق', 'منتهي'];
  const priorities: Priority[] = ['عالي', 'متوسط', 'منخفض'];
  const lawyers = ['المستشار محمد أحمد', 'المستشارة سارة أحمد', 'المستشار خالد عبدالله'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newCase = {
      ...formData,
      id: Date.now().toString(),
      caseNumber: `LAW-2024-${String(Date.now()).slice(-3)}`,
      createdDate: new Date().toISOString().split('T')[0],
      lastUpdated: new Date().toISOString().split('T')[0],
      documents: []
    };
    onSave(newCase);
    setFormData({
      title: '',
      client: '',
      caseType: 'مدني',
      status: 'جديد',
      priority: 'متوسط',
      description: '',
      assignedLawyer: '',
      nextHearing: ''
    });
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between rounded-t-xl">
          <h2 className="text-xl font-bold text-gray-900">إضافة قضية جديدة</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">عنوان القضية</label>
            <input
              type="text"
              required
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-amber-500"
              placeholder="أدخل عنوان القضية"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">اسم العميل</label>
            <input
              type="text"
              required
              value={formData.client}
              onChange={(e) => setFormData({ ...formData, client: e.target.value })}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-amber-500"
              placeholder="اسم العميل"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">نوع القضية</label>
              <select
                value={formData.caseType}
                onChange={(e) => setFormData({ ...formData, caseType: e.target.value as CaseType })}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-amber-500"
              >
                {caseTypes.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">الأولوية</label>
              <select
                value={formData.priority}
                onChange={(e) => setFormData({ ...formData, priority: e.target.value as Priority })}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-amber-500"
              >
                {priorities.map(priority => (
                  <option key={priority} value={priority}>{priority}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">المحامي المسؤول</label>
            <select
              required
              value={formData.assignedLawyer}
              onChange={(e) => setFormData({ ...formData, assignedLawyer: e.target.value })}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-amber-500"
            >
              <option value="">اختر المحامي</option>
              {lawyers.map(lawyer => (
                <option key={lawyer} value={lawyer}>{lawyer}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">تاريخ الجلسة القادمة</label>
            <input
              type="date"
              value={formData.nextHearing}
              onChange={(e) => setFormData({ ...formData, nextHearing: e.target.value })}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">وصف القضية</label>
            <textarea
              required
              rows={3}
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-amber-500"
              placeholder="وصف تفصيلي للقضية"
            />
          </div>

          <div className="flex items-center justify-end space-x-3 rtl:space-x-reverse pt-4 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg font-medium transition-colors"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-lg font-medium transition-colors flex items-center space-x-2 rtl:space-x-reverse"
            >
              <Save className="h-4 w-4" />
              <span>حفظ</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};