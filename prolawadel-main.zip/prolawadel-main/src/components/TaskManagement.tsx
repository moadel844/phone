import React, { useState } from 'react';
import { 
  CheckSquare, 
  Clock, 
  AlertCircle, 
  User, 
  Calendar,
  Plus,
  Filter,
  Search,
  Edit,
  Trash2
} from 'lucide-react';
import { Task, Priority, TaskStatus } from '../types';

interface TaskManagementProps {
  tasks: Task[];
  onAddTask: (task: Task) => void;
  onUpdateTask: (task: Task) => void;
  onDeleteTask: (id: string) => void;
}

export const TaskManagement: React.FC<TaskManagementProps> = ({
  tasks,
  onAddTask,
  onUpdateTask,
  onDeleteTask
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<TaskStatus | ''>('');
  const [priorityFilter, setPriorityFilter] = useState<Priority | ''>('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  const filteredTasks = tasks.filter(task => {
    const matchesSearch = task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         task.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = !statusFilter || task.status === statusFilter;
    const matchesPriority = !priorityFilter || task.priority === priorityFilter;
    
    return matchesSearch && matchesStatus && matchesPriority;
  });

  const getStatusColor = (status: TaskStatus) => {
    switch (status) {
      case 'جديد': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'قيد التنفيذ': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'مكتمل': return 'bg-green-100 text-green-800 border-green-200';
      case 'متأخر': return 'bg-red-100 text-red-800 border-red-200';
      case 'ملغي': return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'معلق': return 'bg-orange-100 text-orange-800 border-orange-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPriorityIcon = (priority: Priority) => {
    switch (priority) {
      case 'عاجل': return <AlertCircle className="h-4 w-4 text-red-600" />;
      case 'عالي': return <AlertCircle className="h-4 w-4 text-orange-600" />;
      case 'متوسط': return <Clock className="h-4 w-4 text-yellow-600" />;
      case 'منخفض': return <CheckSquare className="h-4 w-4 text-green-600" />;
      default: return <Clock className="h-4 w-4 text-gray-600" />;
    }
  };

  const TaskCard = ({ task }: { task: Task }) => (
    <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:shadow-xl transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center space-x-2 rtl:space-x-reverse mb-2">
            {getPriorityIcon(task.priority)}
            <span className={`text-xs px-2 py-1 rounded-full border ${getStatusColor(task.status)}`}>
              {task.status}
            </span>
          </div>
          <h3 className="text-lg font-bold text-gray-900 mb-2">{task.title}</h3>
          <p className="text-gray-600 text-sm line-clamp-2 mb-3">{task.description}</p>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center space-x-3 rtl:space-x-reverse text-sm text-gray-600">
          <User className="h-4 w-4 text-gray-400" />
          <span>مسند إلى: {task.assignedTo}</span>
        </div>
        
        <div className="flex items-center space-x-3 rtl:space-x-reverse text-sm text-gray-600">
          <Calendar className="h-4 w-4 text-gray-400" />
          <span>موعد التسليم: {new Date(task.dueDate).toLocaleDateString('ar-EG')}</span>
        </div>

        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center space-x-2 rtl:space-x-reverse text-gray-600">
            <Clock className="h-4 w-4" />
            <span>
              {task.actualHours ? 
                `${task.actualHours}/${task.estimatedHours} ساعة` : 
                `${task.estimatedHours} ساعة مقدرة`
              }
            </span>
          </div>
          
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <button className="p-1 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded">
              <Edit className="h-4 w-4" />
            </button>
            <button
              onClick={() => onDeleteTask(task.id)}
              className="p-1 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {task.dependencies.length > 0 && (
        <div className="mt-4 pt-4 border-t border-gray-100">
          <p className="text-xs text-gray-500 mb-2">يعتمد على:</p>
          <div className="flex flex-wrap gap-1">
            {task.dependencies.map((dep, index) => (
              <span key={index} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                مهمة #{dep}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  const tasksByStatus = {
    'جديد': filteredTasks.filter(t => t.status === 'جديد'),
    'قيد التنفيذ': filteredTasks.filter(t => t.status === 'قيد التنفيذ'),
    'مكتمل': filteredTasks.filter(t => t.status === 'مكتمل'),
    'متأخر': filteredTasks.filter(t => t.status === 'متأخر')
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">إدارة المهام</h2>
          <p className="text-gray-600 mt-1">تنظيم ومتابعة جميع المهام والأنشطة</p>
        </div>
        <button
          onClick={() => setIsAddModalOpen(true)}
          className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg font-medium transition-colors flex items-center space-x-2 rtl:space-x-reverse"
        >
          <Plus className="h-4 w-4" />
          <span>مهمة جديدة</span>
        </button>
      </div>

      {/* فلاتر البحث */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <input
              type="text"
              placeholder="البحث في المهام..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full border border-gray-300 rounded-lg pr-10 pl-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as TaskStatus | '')}
            className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">جميع الحالات</option>
            <option value="جديد">جديد</option>
            <option value="قيد التنفيذ">قيد التنفيذ</option>
            <option value="مكتمل">مكتمل</option>
            <option value="متأخر">متأخر</option>
            <option value="ملغي">ملغي</option>
            <option value="معلق">معلق</option>
          </select>

          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value as Priority | '')}
            className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">جميع الأولويات</option>
            <option value="عاجل">عاجل</option>
            <option value="عالي">عالي</option>
            <option value="متوسط">متوسط</option>
            <option value="منخفض">منخفض</option>
          </select>

          <div className="flex items-center space-x-2 rtl:space-x-reverse text-sm text-gray-600">
            <span>إجمالي المهام: {filteredTasks.length}</span>
          </div>
        </div>
      </div>

      {/* إحصائيات سريعة */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <CheckSquare className="h-5 w-5 text-blue-600" />
            <span className="text-sm font-medium text-blue-900">مهام جديدة</span>
          </div>
          <p className="text-2xl font-bold text-blue-600 mt-2">{tasksByStatus['جديد'].length}</p>
        </div>

        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <Clock className="h-5 w-5 text-yellow-600" />
            <span className="text-sm font-medium text-yellow-900">قيد التنفيذ</span>
          </div>
          <p className="text-2xl font-bold text-yellow-600 mt-2">{tasksByStatus['قيد التنفيذ'].length}</p>
        </div>

        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <CheckSquare className="h-5 w-5 text-green-600" />
            <span className="text-sm font-medium text-green-900">مكتملة</span>
          </div>
          <p className="text-2xl font-bold text-green-600 mt-2">{tasksByStatus['مكتمل'].length}</p>
        </div>

        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <AlertCircle className="h-5 w-5 text-red-600" />
            <span className="text-sm font-medium text-red-900">متأخرة</span>
          </div>
          <p className="text-2xl font-bold text-red-600 mt-2">{tasksByStatus['متأخر'].length}</p>
        </div>
      </div>

      {/* عرض المهام */}
      {filteredTasks.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-xl shadow-lg">
          <CheckSquare className="h-16 w-16 mx-auto text-gray-300 mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">لا توجد مهام</h3>
          <p className="text-gray-600 mb-6">ابدأ بإضافة مهمة جديدة</p>
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg font-medium transition-colors"
          >
            إضافة مهمة جديدة
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTasks.map((task) => (
            <TaskCard key={task.id} task={task} />
          ))}
        </div>
      )}
    </div>
  );
};