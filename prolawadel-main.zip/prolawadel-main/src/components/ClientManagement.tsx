import React, { useState } from 'react';
import { User, Phone, Mail, MapPin, Plus, Edit, Trash2, Star, DollarSign, FileText, Calendar } from 'lucide-react';
import { Client } from '../types';

interface ClientManagementProps {
  clients: Client[];
  onAddClient: (client: Client) => void;
  onUpdateClient: (client: Client) => void;
  onDeleteClient: (id: string) => void;
}

export const ClientManagement: React.FC<ClientManagementProps> = ({
  clients,
  onAddClient,
  onUpdateClient,
  onDeleteClient
}) => {
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredClients = clients.filter(client =>
    client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    client.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    client.phone.includes(searchTerm)
  );

  const ClientCard = ({ client }: { client: Client }) => (
    <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow border border-gray-100">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3 rtl:space-x-reverse">
          <div className="bg-blue-100 p-3 rounded-full">
            <User className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-gray-900">{client.name}</h3>
            <p className="text-sm text-gray-600">{client.type}</p>
          </div>
        </div>
        <div className="flex items-center space-x-1 rtl:space-x-reverse">
          {[...Array(5)].map((_, i) => (
            <Star
              key={i}
              className={`h-4 w-4 ${
                i < client.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
              }`}
            />
          ))}
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center space-x-2 rtl:space-x-reverse text-sm text-gray-600">
          <Phone className="h-4 w-4" />
          <span>{client.phone}</span>
        </div>
        <div className="flex items-center space-x-2 rtl:space-x-reverse text-sm text-gray-600">
          <Mail className="h-4 w-4" />
          <span>{client.email}</span>
        </div>
        <div className="flex items-center space-x-2 rtl:space-x-reverse text-sm text-gray-600">
          <MapPin className="h-4 w-4" />
          <span className="line-clamp-1">{client.address}</span>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t border-gray-100">
        <div className="text-center">
          <div className="flex items-center justify-center space-x-1 rtl:space-x-reverse">
            <FileText className="h-4 w-4 text-blue-600" />
            <span className="text-sm font-medium text-gray-900">{client.cases.length}</span>
          </div>
          <p className="text-xs text-gray-600">قضية</p>
        </div>
        <div className="text-center">
          <div className="flex items-center justify-center space-x-1 rtl:space-x-reverse">
            <DollarSign className="h-4 w-4 text-green-600" />
            <span className="text-sm font-medium text-gray-900">
              {client.totalPaid.toLocaleString('ar-EG')}
            </span>
          </div>
          <p className="text-xs text-gray-600">مدفوع</p>
        </div>
        <div className="text-center">
          <div className="flex items-center justify-center space-x-1 rtl:space-x-reverse">
            <Calendar className="h-4 w-4 text-purple-600" />
            <span className="text-sm font-medium text-gray-900">
              {new Date(client.registrationDate).getFullYear()}
            </span>
          </div>
          <p className="text-xs text-gray-600">عضو منذ</p>
        </div>
      </div>

      <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100">
        <div className="flex items-center space-x-2 rtl:space-x-reverse">
          <button
            onClick={() => setSelectedClient(client)}
            className="text-blue-600 hover:text-blue-700 text-sm font-medium"
          >
            عرض التفاصيل
          </button>
        </div>
        <div className="flex items-center space-x-2 rtl:space-x-reverse">
          <button className="p-1 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded">
            <Edit className="h-4 w-4" />
          </button>
          <button
            onClick={() => onDeleteClient(client.id)}
            className="p-1 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">إدارة العملاء</h2>
          <p className="text-gray-600 mt-1">إدارة شاملة لبيانات العملاء والتواصل معهم</p>
        </div>
        <button
          onClick={() => setIsAddModalOpen(true)}
          className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg font-medium transition-colors flex items-center space-x-2 rtl:space-x-reverse"
        >
          <Plus className="h-4 w-4" />
          <span>عميل جديد</span>
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <input
            type="text"
            placeholder="البحث في العملاء..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-1 max-w-md border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <div className="flex items-center space-x-4 rtl:space-x-reverse text-sm text-gray-600">
            <span>إجمالي العملاء: {clients.length}</span>
            <span>العملاء النشطين: {clients.filter(c => c.cases.length > 0).length}</span>
          </div>
        </div>

        {filteredClients.length === 0 ? (
          <div className="text-center py-16">
            <User className="h-16 w-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">لا توجد عملاء</h3>
            <p className="text-gray-600 mb-6">ابدأ بإضافة عميل جديد</p>
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg font-medium transition-colors"
            >
              إضافة عميل جديد
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredClients.map((client) => (
              <ClientCard key={client.id} client={client} />
            ))}
          </div>
        )}
      </div>

      {/* إحصائيات العملاء */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <User className="h-5 w-5 text-blue-600" />
            <span className="text-sm font-medium text-blue-900">إجمالي العملاء</span>
          </div>
          <p className="text-2xl font-bold text-blue-600 mt-2">{clients.length}</p>
        </div>

        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <FileText className="h-5 w-5 text-green-600" />
            <span className="text-sm font-medium text-green-900">عملاء نشطين</span>
          </div>
          <p className="text-2xl font-bold text-green-600 mt-2">
            {clients.filter(c => c.cases.length > 0).length}
          </p>
        </div>

        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <DollarSign className="h-5 w-5 text-yellow-600" />
            <span className="text-sm font-medium text-yellow-900">إجمالي المدفوعات</span>
          </div>
          <p className="text-2xl font-bold text-yellow-600 mt-2">
            {clients.reduce((sum, c) => sum + c.totalPaid, 0).toLocaleString('ar-EG')}
          </p>
        </div>

        <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <Star className="h-5 w-5 text-purple-600" />
            <span className="text-sm font-medium text-purple-900">متوسط التقييم</span>
          </div>
          <p className="text-2xl font-bold text-purple-600 mt-2">
            {clients.length > 0 
              ? (clients.reduce((sum, c) => sum + c.rating, 0) / clients.length).toFixed(1)
              : '0.0'
            }
          </p>
        </div>
      </div>
    </div>
  );
};