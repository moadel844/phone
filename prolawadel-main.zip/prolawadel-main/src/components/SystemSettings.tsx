import React, { useState } from 'react';
import { 
  Settings, 
  Shield, 
  Bell, 
  Database, 
  Globe, 
  Users,
  Save,
  RefreshCw,
  Download,
  Upload
} from 'lucide-react';
import { SystemSettings as SystemSettingsType } from '../types';

interface SystemSettingsProps {
  settings: SystemSettingsType;
  onUpdateSettings: (settings: SystemSettingsType) => void;
}

export const SystemSettings: React.FC<SystemSettingsProps> = ({
  settings,
  onUpdateSettings
}) => {
  const [activeTab, setActiveTab] = useState<'general' | 'security' | 'notifications' | 'integrations' | 'backup' | 'users'>('general');
  const [formData, setFormData] = useState(settings);

  const handleSave = () => {
    onUpdateSettings(formData);
    // إظهار رسالة نجح الحفظ
  };

  const tabs = [
    { id: 'general', name: 'عام', icon: Settings },
    { id: 'security', name: 'الأمان', icon: Shield },
    { id: 'notifications', name: 'الإشعارات', icon: Bell },
    { id: 'integrations', name: 'التكامل', icon: Globe },
    { id: 'backup', name: 'النسخ الاحتياطي', icon: Database },
    { id: 'users', name: 'المستخدمين', icon: Users }
  ];

  const renderGeneralSettings = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">اسم المكتب</label>
          <input
            type="text"
            value={formData.general.officeName}
            onChange={(e) => setFormData({
              ...formData,
              general: { ...formData.general, officeName: e.target.value }
            })}
            className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">رقم الهاتف</label>
          <input
            type="tel"
            value={formData.general.phone}
            onChange={(e) => setFormData({
              ...formData,
              general: { ...formData.general, phone: e.target.value }
            })}
            className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">البريد الإلكتروني</label>
          <input
            type="email"
            value={formData.general.email}
            onChange={(e) => setFormData({
              ...formData,
              general: { ...formData.general, email: e.target.value }
            })}
            className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">الموقع الإلكتروني</label>
          <input
            type="url"
            value={formData.general.website}
            onChange={(e) => setFormData({
              ...formData,
              general: { ...formData.general, website: e.target.value }
            })}
            className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">المنطقة الزمنية</label>
          <select
            value={formData.general.timezone}
            onChange={(e) => setFormData({
              ...formData,
              general: { ...formData.general, timezone: e.target.value }
            })}
            className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="Africa/Cairo">القاهرة (GMT+2)</option>
            <option value="Asia/Riyadh">الرياض (GMT+3)</option>
            <option value="Asia/Dubai">دبي (GMT+4)</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">العملة</label>
          <select
            value={formData.general.currency}
            onChange={(e) => setFormData({
              ...formData,
              general: { ...formData.general, currency: e.target.value }
            })}
            className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="EGP">جنيه مصري</option>
            <option value="SAR">ريال سعودي</option>
            <option value="AED">درهم إماراتي</option>
            <option value="USD">دولار أمريكي</option>
          </select>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">العنوان</label>
        <textarea
          rows={3}
          value={formData.general.address}
          onChange={(e) => setFormData({
            ...formData,
            general: { ...formData.general, address: e.target.value }
          })}
          className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>
    </div>
  );

  const renderSecuritySettings = () => (
    <div className="space-y-6">
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <div className="flex items-center space-x-2 rtl:space-x-reverse">
          <Shield className="h-5 w-5 text-yellow-600" />
          <span className="text-sm font-medium text-yellow-800">إعدادات الأمان الحساسة</span>
        </div>
        <p className="text-sm text-yellow-700 mt-1">
          تأكد من مراجعة جميع الإعدادات بعناية قبل الحفظ
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium text-gray-700">المصادقة الثنائية</label>
            <input
              type="checkbox"
              checked={formData.security.twoFactorAuth}
              onChange={(e) => setFormData({
                ...formData,
                security: { ...formData.security, twoFactorAuth: e.target.checked }
              })}
              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
          </div>

          <div className="flex items-center justify-between">
            <label className="text-sm font-medium text-gray-700">تشفير البيانات</label>
            <input
              type="checkbox"
              checked={formData.security.encryptionEnabled}
              onChange={(e) => setFormData({
                ...formData,
                security: { ...formData.security, encryptionEnabled: e.target.checked }
              })}
              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
          </div>

          <div className="flex items-center justify-between">
            <label className="text-sm font-medium text-gray-700">سجل التدقيق</label>
            <input
              type="checkbox"
              checked={formData.security.auditLogging}
              onChange={(e) => setFormData({
                ...formData,
                security: { ...formData.security, auditLogging: e.target.checked }
              })}
              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              مهلة انتهاء الجلسة (بالدقائق)
            </label>
            <input
              type="number"
              value={formData.security.sessionTimeout}
              onChange={(e) => setFormData({
                ...formData,
                security: { ...formData.security, sessionTimeout: parseInt(e.target.value) }
              })}
              className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>

      <div className="bg-gray-50 rounded-lg p-4">
        <h4 className="font-medium text-gray-900 mb-3">سياسة كلمة المرور</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">الحد الأدنى للطول</label>
            <input
              type="number"
              value={formData.security.passwordPolicy.minLength}
              onChange={(e) => setFormData({
                ...formData,
                security: {
                  ...formData.security,
                  passwordPolicy: {
                    ...formData.security.passwordPolicy,
                    minLength: parseInt(e.target.value)
                  }
                }
              })}
              className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="space-y-2">
            {[
              { key: 'requireUppercase', label: 'أحرف كبيرة' },
              { key: 'requireLowercase', label: 'أحرف صغيرة' },
              { key: 'requireNumbers', label: 'أرقام' },
              { key: 'requireSymbols', label: 'رموز' }
            ].map((option) => (
              <div key={option.key} className="flex items-center justify-between">
                <label className="text-sm text-gray-700">{option.label}</label>
                <input
                  type="checkbox"
                  checked={formData.security.passwordPolicy[option.key as keyof typeof formData.security.passwordPolicy] as boolean}
                  onChange={(e) => setFormData({
                    ...formData,
                    security: {
                      ...formData.security,
                      passwordPolicy: {
                        ...formData.security.passwordPolicy,
                        [option.key]: e.target.checked
                      }
                    }
                  })}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  const renderNotificationSettings = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="space-y-4">
          <h4 className="font-medium text-gray-900">قنوات الإشعارات</h4>
          {[
            { key: 'emailEnabled', label: 'البريد الإلكتروني', icon: '📧' },
            { key: 'smsEnabled', label: 'الرسائل النصية', icon: '📱' },
            { key: 'pushEnabled', label: 'الإشعارات المباشرة', icon: '🔔' }
          ].map((option) => (
            <div key={option.key} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <span className="text-lg">{option.icon}</span>
                <label className="text-sm font-medium text-gray-700">{option.label}</label>
              </div>
              <input
                type="checkbox"
                checked={formData.notifications[option.key as keyof typeof formData.notifications] as boolean}
                onChange={(e) => setFormData({
                  ...formData,
                  notifications: {
                    ...formData.notifications,
                    [option.key]: e.target.checked
                  }
                })}
                className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
            </div>
          ))}
        </div>

        <div className="md:col-span-2">
          <h4 className="font-medium text-gray-900 mb-4">إعدادات التذكيرات (بالساعات)</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              { key: 'appointmentReminder', label: 'تذكير المواعيد' },
              { key: 'hearingReminder', label: 'تذكير الجلسات' },
              { key: 'taskDeadlineReminder', label: 'تذكير المهام' },
              { key: 'paymentDueReminder', label: 'تذكير المدفوعات' }
            ].map((option) => (
              <div key={option.key}>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {option.label}
                </label>
                <input
                  type="number"
                  value={formData.notifications.reminderSettings[option.key as keyof typeof formData.notifications.reminderSettings]}
                  onChange={(e) => setFormData({
                    ...formData,
                    notifications: {
                      ...formData.notifications,
                      reminderSettings: {
                        ...formData.notifications.reminderSettings,
                        [option.key]: parseInt(e.target.value)
                      }
                    }
                  })}
                  className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  const renderBackupSettings = () => (
    <div className="space-y-6">
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-center space-x-2 rtl:space-x-reverse">
          <Database className="h-5 w-5 text-blue-600" />
          <span className="text-sm font-medium text-blue-800">النسخ الاحتياطي التلقائي</span>
        </div>
        <p className="text-sm text-blue-700 mt-1">
          يتم إنشاء نسخ احتياطية تلقائية لحماية بياناتك
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium text-gray-700">النسخ الاحتياطي التلقائي</label>
            <input
              type="checkbox"
              checked={formData.backup.autoBackup}
              onChange={(e) => setFormData({
                ...formData,
                backup: { ...formData.backup, autoBackup: e.target.checked }
              })}
              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">تكرار النسخ</label>
            <select
              value={formData.backup.backupFrequency}
              onChange={(e) => setFormData({
                ...formData,
                backup: { ...formData.backup, backupFrequency: e.target.value as any }
              })}
              className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="يومي">يومي</option>
              <option value="أسبوعي">أسبوعي</option>
              <option value="شهري">شهري</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              فترة الاحتفاظ (بالأيام)
            </label>
            <input
              type="number"
              value={formData.backup.retentionPeriod}
              onChange={(e) => setFormData({
                ...formData,
                backup: { ...formData.backup, retentionPeriod: parseInt(e.target.value) }
              })}
              className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">موقع النسخ الاحتياطي</label>
            <input
              type="text"
              value={formData.backup.backupLocation}
              onChange={(e) => setFormData({
                ...formData,
                backup: { ...formData.backup, backupLocation: e.target.value }
              })}
              className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="space-y-2">
            <button className="w-full bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center justify-center space-x-2 rtl:space-x-reverse">
              <Download className="h-4 w-4" />
              <span>إنشاء نسخة احتياطية الآن</span>
            </button>
            
            <button className="w-full bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center justify-center space-x-2 rtl:space-x-reverse">
              <Upload className="h-4 w-4" />
              <span>استعادة من نسخة احتياطية</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'general': return renderGeneralSettings();
      case 'security': return renderSecuritySettings();
      case 'notifications': return renderNotificationSettings();
      case 'backup': return renderBackupSettings();
      case 'integrations':
        return (
          <div className="text-center py-16">
            <Globe className="h-16 w-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">إعدادات التكامل</h3>
            <p className="text-gray-600">قريباً - إعدادات التكامل مع الأنظمة الخارجية</p>
          </div>
        );
      case 'users':
        return (
          <div className="text-center py-16">
            <Users className="h-16 w-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">إدارة المستخدمين</h3>
            <p className="text-gray-600">قريباً - إدارة المستخدمين والصلاحيات</p>
          </div>
        );
      default: return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">إعدادات النظام</h2>
          <p className="text-gray-600 mt-1">إدارة وتخصيص إعدادات النظام</p>
        </div>
        
        <div className="flex items-center space-x-2 rtl:space-x-reverse">
          <button className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2 rtl:space-x-reverse">
            <RefreshCw className="h-4 w-4" />
            <span>إعادة تعيين</span>
          </button>
          <button
            onClick={handleSave}
            className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2 rtl:space-x-reverse"
          >
            <Save className="h-4 w-4" />
            <span>حفظ التغييرات</span>
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-lg">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 rtl:space-x-reverse px-6">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 rtl:space-x-reverse py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{tab.name}</span>
                </button>
              );
            })}
          </nav>
        </div>
        
        <div className="p-6">
          {renderContent()}
        </div>
      </div>
    </div>
  );
};