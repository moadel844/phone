import React, { useState } from 'react';
import { Bell, BellOff, AlertCircle, Info, CheckCircle, XCircle, Clock, Trash2, BookMarked as MarkAsRead } from 'lucide-react';
import { Notification, NotificationType, Priority } from '../types';

interface NotificationCenterProps {
  notifications: Notification[];
  onMarkAsRead: (id: string) => void;
  onMarkAllAsRead: () => void;
  onDeleteNotification: (id: string) => void;
  onDeleteAll: () => void;
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({
  notifications,
  onMarkAsRead,
  onMarkAllAsRead,
  onDeleteNotification,
  onDeleteAll
}) => {
  const [filter, setFilter] = useState<'all' | 'unread' | NotificationType>('all');

  const filteredNotifications = notifications.filter(notification => {
    if (filter === 'all') return true;
    if (filter === 'unread') return !notification.read;
    return notification.type === filter;
  });

  const unreadCount = notifications.filter(n => !n.read).length;

  const getNotificationIcon = (type: NotificationType) => {
    switch (type) {
      case 'تذكير': return <Clock className="h-5 w-5 text-blue-600" />;
      case 'تحديث': return <Info className="h-5 w-5 text-green-600" />;
      case 'تحذير': return <AlertCircle className="h-5 w-5 text-yellow-600" />;
      case 'معلومات': return <Info className="h-5 w-5 text-blue-600" />;
      case 'طارئ': return <XCircle className="h-5 w-5 text-red-600" />;
      case 'نظام': return <CheckCircle className="h-5 w-5 text-gray-600" />;
      default: return <Bell className="h-5 w-5 text-gray-600" />;
    }
  };

  const getPriorityColor = (priority: Priority) => {
    switch (priority) {
      case 'عاجل': return 'border-r-4 border-red-500';
      case 'عالي': return 'border-r-4 border-orange-500';
      case 'متوسط': return 'border-r-4 border-yellow-500';
      case 'منخفض': return 'border-r-4 border-green-500';
      default: return 'border-r-4 border-gray-300';
    }
  };

  const NotificationItem = ({ notification }: { notification: Notification }) => (
    <div
      className={`p-4 border-b border-gray-100 hover:bg-gray-50 transition-colors ${
        !notification.read ? 'bg-blue-50' : ''
      } ${getPriorityColor(notification.priority)}`}
    >
      <div className="flex items-start space-x-3 rtl:space-x-reverse">
        <div className="flex-shrink-0 mt-1">
          {getNotificationIcon(notification.type)}
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h4 className={`text-sm font-medium ${!notification.read ? 'text-gray-900' : 'text-gray-700'}`}>
                {notification.title}
              </h4>
              <p className="text-sm text-gray-600 mt-1 line-clamp-2">
                {notification.message}
              </p>
              <div className="flex items-center space-x-4 rtl:space-x-reverse mt-2 text-xs text-gray-500">
                <span>{new Date(notification.createdDate).toLocaleString('ar-EG')}</span>
                <span className="px-2 py-1 bg-gray-100 rounded-full">{notification.type}</span>
                <span className={`px-2 py-1 rounded-full ${
                  notification.priority === 'عاجل' ? 'bg-red-100 text-red-800' :
                  notification.priority === 'عالي' ? 'bg-orange-100 text-orange-800' :
                  notification.priority === 'متوسط' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-green-100 text-green-800'
                }`}>
                  {notification.priority}
                </span>
              </div>
            </div>
            
            <div className="flex items-center space-x-2 rtl:space-x-reverse ml-4">
              {!notification.read && (
                <button
                  onClick={() => onMarkAsRead(notification.id)}
                  className="p-1 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded"
                  title="تحديد كمقروء"
                >
                  <CheckCircle className="h-4 w-4" />
                </button>
              )}
              <button
                onClick={() => onDeleteNotification(notification.id)}
                className="p-1 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded"
                title="حذف"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3 rtl:space-x-reverse">
          <Bell className="h-6 w-6 text-gray-900" />
          <div>
            <h2 className="text-2xl font-bold text-gray-900">مركز الإشعارات</h2>
            <p className="text-gray-600 mt-1">
              {unreadCount > 0 ? `${unreadCount} إشعار غير مقروء` : 'جميع الإشعارات مقروءة'}
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2 rtl:space-x-reverse">
          {unreadCount > 0 && (
            <button
              onClick={onMarkAllAsRead}
              className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2 rtl:space-x-reverse"
            >
              <CheckCircle className="h-4 w-4" />
              <span>تحديد الكل كمقروء</span>
            </button>
          )}
          <button
            onClick={onDeleteAll}
            className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2 rtl:space-x-reverse"
          >
            <Trash2 className="h-4 w-4" />
            <span>حذف الكل</span>
          </button>
        </div>
      </div>

      {/* فلاتر الإشعارات */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center space-x-4 rtl:space-x-reverse">
          <span className="text-sm font-medium text-gray-700">تصفية حسب:</span>
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            {[
              { key: 'all', label: 'الكل' },
              { key: 'unread', label: 'غير مقروء' },
              { key: 'تذكير', label: 'تذكيرات' },
              { key: 'تحديث', label: 'تحديثات' },
              { key: 'تحذير', label: 'تحذيرات' },
              { key: 'طارئ', label: 'طارئة' }
            ].map((option) => (
              <button
                key={option.key}
                onClick={() => setFilter(option.key as any)}
                className={`px-3 py-1 text-sm rounded-full transition-colors ${
                  filter === option.key
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {option.label}
                {option.key === 'unread' && unreadCount > 0 && (
                  <span className="ml-1 bg-red-500 text-white text-xs px-1 rounded-full">
                    {unreadCount}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* قائمة الإشعارات */}
      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        {filteredNotifications.length === 0 ? (
          <div className="text-center py-16">
            <BellOff className="h-16 w-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">لا توجد إشعارات</h3>
            <p className="text-gray-600">
              {filter === 'unread' 
                ? 'جميع الإشعارات مقروءة' 
                : 'لا توجد إشعارات تطابق الفلتر المحدد'
              }
            </p>
          </div>
        ) : (
          <div className="divide-y divide-gray-100">
            {filteredNotifications.map((notification) => (
              <NotificationItem key={notification.id} notification={notification} />
            ))}
          </div>
        )}
      </div>

      {/* إحصائيات الإشعارات */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <Bell className="h-5 w-5 text-blue-600" />
            <span className="text-sm font-medium text-blue-900">إجمالي الإشعارات</span>
          </div>
          <p className="text-2xl font-bold text-blue-600 mt-2">{notifications.length}</p>
        </div>

        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <AlertCircle className="h-5 w-5 text-yellow-600" />
            <span className="text-sm font-medium text-yellow-900">غير مقروء</span>
          </div>
          <p className="text-2xl font-bold text-yellow-600 mt-2">{unreadCount}</p>
        </div>

        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <XCircle className="h-5 w-5 text-red-600" />
            <span className="text-sm font-medium text-red-900">طارئة</span>
          </div>
          <p className="text-2xl font-bold text-red-600 mt-2">
            {notifications.filter(n => n.type === 'طارئ').length}
          </p>
        </div>

        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <CheckCircle className="h-5 w-5 text-green-600" />
            <span className="text-sm font-medium text-green-900">مقروء</span>
          </div>
          <p className="text-2xl font-bold text-green-600 mt-2">
            {notifications.filter(n => n.read).length}
          </p>
        </div>
      </div>
    </div>
  );
};