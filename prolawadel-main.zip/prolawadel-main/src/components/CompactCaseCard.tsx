import React from 'react';
import { Calendar, User, FileText, AlertCircle, Clock, CheckCircle } from 'lucide-react';
import { Case } from '../types/core';

interface CompactCaseCardProps {
  case: Case;
  onClick: (caseItem: Case) => void;
}

export const CompactCaseCard: React.FC<CompactCaseCardProps> = ({ case: caseItem, onClick }) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'جديد': return 'bg-blue-100 text-blue-800';
      case 'قيد المراجعة': return 'bg-yellow-100 text-yellow-800';
      case 'في المحكمة': return 'bg-purple-100 text-purple-800';
      case 'مؤجل': return 'bg-orange-100 text-orange-800';
      case 'مغلق': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'عالي': return <AlertCircle className="h-4 w-4 text-red-600" />;
      case 'متوسط': return <Clock className="h-4 w-4 text-yellow-600" />;
      case 'منخفض': return <CheckCircle className="h-4 w-4 text-green-600" />;
      default: return <Clock className="h-4 w-4 text-gray-600" />;
    }
  };

  return (
    <div
      onClick={() => onClick(caseItem)}
      className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow cursor-pointer border border-gray-100 p-4"
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <div className="flex items-center space-x-2 rtl:space-x-reverse mb-2">
            <span className="text-xs font-mono text-gray-500 bg-gray-100 px-2 py-1 rounded">
              {caseItem.caseNumber}
            </span>
            <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(caseItem.status)}`}>
              {caseItem.status}
            </span>
          </div>
          <h3 className="text-base font-bold text-gray-900 mb-2 line-clamp-2">
            {caseItem.title}
          </h3>
        </div>
        
        <div className="flex items-center space-x-1 rtl:space-x-reverse">
          {getPriorityIcon(caseItem.priority)}
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex items-center space-x-2 rtl:space-x-reverse text-sm text-gray-600">
          <User className="h-3 w-3 text-gray-400" />
          <span className="truncate">{caseItem.client}</span>
        </div>
        
        <div className="flex items-center space-x-2 rtl:space-x-reverse text-sm text-gray-600">
          <FileText className="h-3 w-3 text-gray-400" />
          <span>{caseItem.caseType}</span>
          <span className="text-gray-400">•</span>
          <span className="truncate">{caseItem.assignedLawyer}</span>
        </div>

        {caseItem.nextHearing && (
          <div className="flex items-center space-x-2 rtl:space-x-reverse text-xs text-amber-600 bg-amber-50 px-2 py-1 rounded">
            <Calendar className="h-3 w-3" />
            <span>الجلسة: {new Date(caseItem.nextHearing).toLocaleDateString('ar-EG')}</span>
          </div>
        )}
      </div>

      <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
        <div className="text-xs text-gray-500">
          آخر تحديث: {new Date(caseItem.lastUpdated).toLocaleDateString('ar-EG')}
        </div>
        
        <div className="flex items-center space-x-1 rtl:space-x-reverse text-xs text-gray-500">
          <FileText className="h-3 w-3" />
          <span>{caseItem.documents.length}</span>
        </div>
      </div>
    </div>
  );
};