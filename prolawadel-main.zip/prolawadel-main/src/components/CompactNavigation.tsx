import React from 'react';
import { 
  LayoutDashboard, 
  FileText, 
  Calendar, 
  Users, 
  CheckSquare,
  Scale
} from 'lucide-react';

interface CompactNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export const CompactNavigation: React.FC<CompactNavigationProps> = ({ activeTab, onTabChange }) => {
  const navItems = [
    { id: 'dashboard', name: 'لوحة التحكم', icon: LayoutDashboard },
    { id: 'cases', name: 'القضايا', icon: FileText },
    { id: 'clients', name: 'العملاء', icon: Users },
    { id: 'appointments', name: 'المواعيد', icon: Calendar },
    { id: 'tasks', name: 'المهام', icon: CheckSquare }
  ];

  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-40 shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4 rtl:space-x-reverse">
            <div className="flex items-center space-x-2 rtl:space-x-reverse py-3">
              <div className="bg-gradient-to-r from-amber-500 to-orange-500 p-2 rounded-lg">
                <Scale className="h-5 w-5 text-white" />
              </div>
              <div>
                <span className="text-lg font-bold text-gray-900">المستشار</span>
                <p className="text-xs text-gray-600">نظام إدارة مكتب المحاماة</p>
              </div>
            </div>
            
            <div className="hidden md:flex items-center space-x-1 rtl:space-x-reverse">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => onTabChange(item.id)}
                    className={`flex items-center space-x-2 rtl:space-x-reverse px-3 py-2 rounded-lg font-medium transition-colors text-sm ${
                      activeTab === item.id
                        ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white'
                        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{item.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="text-sm text-gray-600 hidden md:block">
            {new Date().toLocaleDateString('ar-EG')}
          </div>
        </div>

        {/* قائمة متجاوبة للشاشات الصغيرة */}
        <div className="md:hidden pb-3">
          <div className="flex items-center space-x-2 rtl:space-x-reverse overflow-x-auto">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => onTabChange(item.id)}
                  className={`flex items-center space-x-2 rtl:space-x-reverse px-3 py-2 rounded-lg font-medium transition-colors text-sm whitespace-nowrap ${
                    activeTab === item.id
                      ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{item.name}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </nav>
  );
};