import React from 'react';
import { X, Calendar, User, FileText, Download, Eye } from 'lucide-react';
import { Case } from '../types/core';

interface CompactCaseModalProps {
  case: Case | null;
  isOpen: boolean;
  onClose: () => void;
}

export const CompactCaseModal: React.FC<CompactCaseModalProps> = ({ case: caseItem, isOpen, onClose }) => {
  if (!isOpen || !caseItem) return null;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'جديد': return 'bg-blue-100 text-blue-800';
      case 'قيد المراجعة': return 'bg-yellow-100 text-yellow-800';
      case 'في المحكمة': return 'bg-purple-100 text-purple-800';
      case 'مؤجل': return 'bg-orange-100 text-orange-800';
      case 'مغلق': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between rounded-t-xl">
          <h2 className="text-xl font-bold text-gray-900">تفاصيل القضية</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <div className="p-6">
          <div className="space-y-6">
            <div>
              <div className="flex items-center space-x-3 rtl:space-x-reverse mb-3">
                <span className="text-sm font-mono text-gray-500 bg-gray-100 px-2 py-1 rounded">
                  {caseItem.caseNumber}
                </span>
                <span className={`text-sm px-2 py-1 rounded-full ${getStatusColor(caseItem.status)}`}>
                  {caseItem.status}
                </span>
              </div>
              
              <h1 className="text-2xl font-bold text-gray-900 mb-3">{caseItem.title}</h1>
              <p className="text-gray-700 leading-relaxed">{caseItem.description}</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="font-semibold text-gray-900 mb-3">معلومات القضية</h3>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2 rtl:space-x-reverse">
                    <User className="h-4 w-4 text-gray-400" />
                    <span className="text-sm text-gray-600">العميل:</span>
                    <span className="text-sm font-medium">{caseItem.client}</span>
                  </div>
                  
                  <div className="flex items-center space-x-2 rtl:space-x-reverse">
                    <FileText className="h-4 w-4 text-gray-400" />
                    <span className="text-sm text-gray-600">النوع:</span>
                    <span className="text-sm font-medium">{caseItem.caseType}</span>
                  </div>
                  
                  <div className="flex items-center space-x-2 rtl:space-x-reverse">
                    <User className="h-4 w-4 text-gray-400" />
                    <span className="text-sm text-gray-600">المحامي:</span>
                    <span className="text-sm font-medium">{caseItem.assignedLawyer}</span>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="font-semibold text-gray-900 mb-3">التواريخ المهمة</h3>
                <div className="space-y-2">
                  <div>
                    <span className="text-sm text-gray-600">تاريخ الإنشاء:</span>
                    <p className="text-sm font-medium">
                      {new Date(caseItem.createdDate).toLocaleDateString('ar-EG')}
                    </p>
                  </div>
                  
                  <div>
                    <span className="text-sm text-gray-600">آخر تحديث:</span>
                    <p className="text-sm font-medium">
                      {new Date(caseItem.lastUpdated).toLocaleDateString('ar-EG')}
                    </p>
                  </div>
                  
                  {caseItem.nextHearing && (
                    <div className="bg-amber-50 border border-amber-200 rounded p-2">
                      <div className="flex items-center space-x-2 rtl:space-x-reverse">
                        <Calendar className="h-4 w-4 text-amber-600" />
                        <div>
                          <span className="text-sm text-amber-700 font-medium">الجلسة القادمة:</span>
                          <p className="text-amber-900 font-semibold">
                            {new Date(caseItem.nextHearing).toLocaleDateString('ar-EG')}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {caseItem.documents.length > 0 && (
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">المستندات المرفقة</h3>
                <div className="space-y-2">
                  {caseItem.documents.map((doc) => (
                    <div key={doc.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3 rtl:space-x-reverse">
                        <FileText className="h-5 w-5 text-amber-600" />
                        <div>
                          <h4 className="text-sm font-medium text-gray-900">{doc.name}</h4>
                          <div className="flex items-center space-x-2 rtl:space-x-reverse text-xs text-gray-500">
                            <span>{doc.type}</span>
                            <span>•</span>
                            <span>{doc.size}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2 rtl:space-x-reverse">
                        <button className="p-1 text-gray-500 hover:text-amber-600 rounded">
                          <Eye className="h-4 w-4" />
                        </button>
                        <button className="p-1 text-gray-500 hover:text-amber-600 rounded">
                          <Download className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {caseItem.notes && (
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="font-semibold text-gray-900 mb-2">الملاحظات</h3>
                <p className="text-gray-700 text-sm leading-relaxed">{caseItem.notes}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};