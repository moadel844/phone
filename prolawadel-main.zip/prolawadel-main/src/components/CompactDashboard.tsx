import React from 'react';
import { BarChart3, FileText, Users, Calendar, TrendingUp } from 'lucide-react';
import { Statistics } from '../types/core';

interface CompactDashboardProps {
  statistics: Statistics;
}

export const CompactDashboard: React.FC<CompactDashboardProps> = ({ statistics }) => {
  const StatCard = ({ title, value, icon: Icon, color }: any) => (
    <div className="bg-white rounded-lg shadow-md p-4 border border-gray-100">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-gray-600 text-sm">{title}</p>
          <p className="text-2xl font-bold text-gray-900 mt-1">{value}</p>
        </div>
        <div className={`p-3 rounded-lg ${color}`}>
          <Icon className="h-6 w-6 text-white" />
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* إحصائيات سريعة */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="إجمالي القضايا"
          value={statistics.totalCases}
          icon={FileText}
          color="bg-blue-500"
        />
        <StatCard
          title="القضايا النشطة"
          value={statistics.activeCases}
          icon={BarChart3}
          color="bg-amber-500"
        />
        <StatCard
          title="الجلسات القادمة"
          value={statistics.upcomingHearings}
          icon={Calendar}
          color="bg-purple-500"
        />
        <StatCard
          title="إجمالي العملاء"
          value={statistics.totalClients}
          icon={Users}
          color="bg-green-500"
        />
      </div>

      {/* الرسوم البيانية */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">توزيع القضايا حسب النوع</h3>
          <div className="space-y-3">
            {Object.entries(statistics.casesByType).map(([type, count]) => (
              count > 0 && (
                <div key={type} className="flex items-center justify-between">
                  <span className="text-gray-700">{type}</span>
                  <div className="flex items-center space-x-2 rtl:space-x-reverse">
                    <div className="w-20 bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-amber-500 h-2 rounded-full" 
                        style={{ width: `${(count / statistics.totalCases) * 100}%` }}
                      ></div>
                    </div>
                    <span className="text-sm font-medium text-gray-900">{count}</span>
                  </div>
                </div>
              )
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">الإحصائيات الشهرية</h3>
          <div className="space-y-3">
            {statistics.monthlyStats.map((stat, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="font-medium text-gray-900 text-sm">{stat.month}</span>
                <div className="flex items-center space-x-4 rtl:space-x-reverse text-sm">
                  <div className="flex items-center space-x-2 rtl:space-x-reverse">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span className="text-gray-600">جديدة: {stat.newCases}</span>
                  </div>
                  <div className="flex items-center space-x-2 rtl:space-x-reverse">
                    <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                    <span className="text-gray-600">مغلقة: {stat.closedCases}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* مؤشرات الأداء */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-lg p-4 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-100 text-sm">معدل النجاح</p>
              <p className="text-2xl font-bold">87%</p>
            </div>
            <TrendingUp className="h-8 w-8 text-green-200" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-amber-500 to-amber-600 rounded-lg p-4 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-amber-100 text-sm">متوسط مدة القضية</p>
              <p className="text-2xl font-bold">4.2</p>
              <p className="text-amber-100 text-xs">شهر</p>
            </div>
            <Calendar className="h-8 w-8 text-amber-200" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg p-4 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-100 text-sm">رضا العملاء</p>
              <p className="text-2xl font-bold">94%</p>
            </div>
            <Users className="h-8 w-8 text-purple-200" />
          </div>
        </div>
      </div>
    </div>
  );
};